/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { KANBAN_TASKS_INITIAL } from './data/planData';
import { KanbanTask, KanbanStatus } from './types';
import { KanbanBoard } from './components/KanbanBoard';
import { SimplifierDemo } from './components/SimplifierDemo';
import { ArchitectureViewer } from './components/ArchitectureViewer';
import { DatabaseApiExplorer } from './components/DatabaseApiExplorer';
import { PromptStudio } from './components/PromptStudio';
import { VideoScriptTeleprompter } from './components/VideoScriptTeleprompter';
import { FullDocViewer } from './components/FullDocViewer';
import {
  Sparkles,
  Trello,
  Layers,
  Database,
  Brain,
  Video,
  BookOpen,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  Github
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'demo' | 'kanban' | 'architecture' | 'dbapi' | 'prompts' | 'video' | 'docs'>('demo');
  const [tasks, setTasks] = useState<KanbanTask[]>(KANBAN_TASKS_INITIAL);

  const handleUpdateStatus = (taskId: string, newStatus: KanbanStatus) => {
    setTasks(prev =>
      prev.map(t => (t.id === taskId ? { ...t, status: newStatus } : t))
    );
  };

  const completedTasks = tasks.filter(t => t.status === 'Review').length;
  const inProgressTasks = tasks.filter(t => t.status === 'In Progress').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-blue-500 selection:text-white">
      {/* Top Navbar */}
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 flex items-center justify-center shadow-md shadow-blue-500/20">
              <TrendingUp size={20} className="text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-bold text-white tracking-tight">
                  Financial News Simplifier
                </h1>
                <span className="hidden sm:inline-flex px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 font-mono">
                  Capstone Plan & Hub
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Democratizing Wall Street journalism for ordinary readers
              </p>
            </div>
          </div>

          {/* Quick Metrics & Links */}
          <div className="flex items-center gap-4 text-xs">
            <div className="hidden md:flex items-center gap-3 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg">
              <span className="flex items-center gap-1.5 text-slate-300">
                <Trello size={13} className="text-blue-400" />
                <span>Sprint Progress:</span>
                <span className="font-mono font-bold text-emerald-400">{completedTasks}/{tasks.length} Done</span>
              </span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400">
                {inProgressTasks} In Progress
              </span>
            </div>

            <div className="flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <ShieldCheck size={13} />
              <span>Mentor-Ready</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="border-t border-slate-800/80 bg-slate-900/60 overflow-x-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex space-x-1 py-1">
            <button
              onClick={() => setActiveTab('demo')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                activeTab === 'demo'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Sparkles size={14} />
              <span>Interactive Simplifier</span>
            </button>

            <button
              onClick={() => setActiveTab('kanban')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                activeTab === 'kanban'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Trello size={14} />
              <span>Kanban Sprint Board ({tasks.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('architecture')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                activeTab === 'architecture'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Layers size={14} />
              <span>System Architecture</span>
            </button>

            <button
              onClick={() => setActiveTab('dbapi')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                activeTab === 'dbapi'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Database size={14} />
              <span>Database & APIs</span>
            </button>

            <button
              onClick={() => setActiveTab('prompts')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                activeTab === 'prompts'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Brain size={14} />
              <span>Prompt Engineering</span>
            </button>

            <button
              onClick={() => setActiveTab('video')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                activeTab === 'video'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Video size={14} />
              <span>Demo Video Teleprompter</span>
            </button>

            <button
              onClick={() => setActiveTab('docs')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                activeTab === 'docs'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <BookOpen size={14} />
              <span>20-Section Plan Manual</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Body */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'demo' && <SimplifierDemo />}
        {activeTab === 'kanban' && <KanbanBoard tasks={tasks} onUpdateStatus={handleUpdateStatus} />}
        {activeTab === 'architecture' && <ArchitectureViewer />}
        {activeTab === 'dbapi' && <DatabaseApiExplorer />}
        {activeTab === 'prompts' && <PromptStudio />}
        {activeTab === 'video' && <VideoScriptTeleprompter />}
        {activeTab === 'docs' && <FullDocViewer />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">Financial News Simplifier Capstone</span>
            <span>•</span>
            <span>Google AI Studio Build & GenAI Architecture</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span className="flex items-center gap-1">
              <CheckCircle2 size={13} className="text-emerald-400" />
              <span>All 20 Sections Documented</span>
            </span>
            <span className="flex items-center gap-1">
              <ShieldCheck size={13} className="text-blue-400" />
              <span>Zero Hardcoded Secrets</span>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
