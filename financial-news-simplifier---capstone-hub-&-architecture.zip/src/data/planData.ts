import {
  KanbanTask,
  UserStory,
  ArticleSample,
  DatabaseTable,
  ApiEndpoint,
  PromptTemplate,
} from '../types';

export const KANBAN_TASKS_INITIAL: KanbanTask[] = [
  // Phase 1: Setup
  {
    id: 'TSK-01',
    task: 'Initialize Git repository with standard branch rules & .gitignore',
    epic: 'Project Setup',
    phase: 'Phase 1: Setup',
    status: 'To Do',
    dependency: 'None',
    deliverable: 'GitHub repo with main/dev branches, .gitignore, and branch protection',
    description: 'Create repository on GitHub, configure standard .gitignore for Node/Python/env secrets, write initial root scaffolding.',
    acceptanceCriteria: ['Repository created on GitHub', 'main and develop branches initialized', '.env and node_modules ignored'],
    definitionOfDone: ['Repository cloned locally', 'First commit pushed', 'README initialized']
  },
  {
    id: 'TSK-02',
    task: 'Configure monorepo/folder architecture & environment templates',
    epic: 'Project Setup',
    phase: 'Phase 1: Setup',
    status: 'To Do',
    dependency: 'TSK-01',
    deliverable: 'frontend/, backend/, and root .env.example with documentation',
    description: 'Organize modular folder layout: frontend, backend, database, ai, tests, and docs with clear separation of concerns.',
    acceptanceCriteria: ['.env.example contains GEMINI_API_KEY, NEWS_API_KEY, PORT, DATABASE_URL', 'Zero real secrets in version control'],
    definitionOfDone: ['Both frontend and backend npm/pip run scripts work', 'README documents environment setup']
  },
  {
    id: 'TSK-03',
    task: 'Install backend core frameworks (Express/FastAPI) and setup CORS/security middlewares',
    epic: 'Project Setup',
    phase: 'Phase 1: Setup',
    status: 'To Do',
    dependency: 'TSK-02',
    deliverable: 'Running backend server with health check /api/health and helmet/cors',
    description: 'Bootstraps backend service, registers json parser, cors for frontend origin, and error handler wrapper.',
    acceptanceCriteria: ['GET /api/health returns 200 OK with timestamp and status', 'CORS allows localhost:5173 / localhost:3000'],
    definitionOfDone: ['curl http://localhost:3000/api/health succeeds', 'Server runs without runtime errors']
  },
  {
    id: 'TSK-04',
    task: 'Scaffold React + Vite frontend with Tailwind CSS and theme design system',
    epic: 'Project Setup',
    phase: 'Phase 1: Setup',
    status: 'To Do',
    dependency: 'TSK-02',
    deliverable: 'Vite React application with Tailwind styling and basic layout components',
    description: 'Initialize responsive UI shell with navigation header, card containers, typography scale, and responsive grid.',
    acceptanceCriteria: ['Vite dev server starts instantly', 'Tailwind utility classes render correctly', 'Header and footer layout responsive'],
    definitionOfDone: ['Browser loads cleanly without console warnings', 'Clean UI baseline ready']
  },

  // Phase 2: News Integration
  {
    id: 'TSK-05',
    task: 'Select and register for Financial News API (NewsAPI / Finnhub / AlphaVantage / RSS)',
    epic: 'News Data Integration',
    phase: 'Phase 2: News Integration',
    status: 'To Do',
    dependency: 'TSK-03',
    deliverable: 'Developer API credentials stored in local .env with quota tracker',
    description: 'Set up free tier API key with backup financial RSS feeds (Reuters, Yahoo Finance) for rate limit resilience.',
    acceptanceCriteria: ['API key obtained and validated', 'Fallback RSS parser or mock feed configured for offline resilience'],
    definitionOfDone: ['Test script successfully queries finance category articles', 'Rate limits documented']
  },
  {
    id: 'TSK-06',
    task: 'Build News Ingestion Service with normalizer and deduplication engine',
    epic: 'News Data Integration',
    phase: 'Phase 2: News Integration',
    status: 'To Do',
    dependency: 'TSK-05',
    deliverable: 'newsService.ts module returning standardized ArticleDTO objects',
    description: 'Fetch top financial headlines, normalize diverse raw schemas into unified fields: title, source, publishedAt, content, url.',
    acceptanceCriteria: ['Handles missing fields gracefully', 'Strips unwanted HTML/JS artifacts', 'Deduplicates by URL hash and title similarity'],
    definitionOfDone: ['Unit tests pass on 10 sample raw API responses', 'Standardized JSON structure matches contract']
  },
  {
    id: 'TSK-07',
    task: 'Implement News Category Filtering & Keyword Search Engine in backend',
    epic: 'News Data Integration',
    phase: 'Phase 2: News Integration',
    status: 'To Do',
    dependency: 'TSK-06',
    deliverable: 'GET /api/news with query parameters: ?category=stocks&search=inflation&page=1',
    description: 'Provide filtered news list with pagination, category tags (Markets, Crypto, Tech, Economy, M&A), and keyword search.',
    acceptanceCriteria: ['Category filtering returns matching articles', 'Search queries query title and content', 'Pagination returns page and total count'],
    definitionOfDone: ['Postman / curl test verified with 200 responses', 'Zero crashes on empty results']
  },

  // Phase 3: AI/LLM Processing
  {
    id: 'TSK-08',
    task: 'Configure Google GenAI SDK (@google/genai) and Gemini 2.5/Flash model integration',
    epic: 'AI/LLM Processing',
    phase: 'Phase 3: AI/LLM',
    status: 'To Do',
    dependency: 'TSK-03',
    deliverable: 'geminiClient.ts wrapper with temperature, schema validation, and retry logic',
    description: 'Initialize Gemini client with environment API key, safety settings, and exponential backoff retry handler.',
    acceptanceCriteria: ['Client connects securely without client-side key leakage', 'Safe timeout handling (15s max)'],
    definitionOfDone: ['Smoke test call returns valid response from Gemini', 'Errors logged with friendly error messages']
  },
  {
    id: 'TSK-09',
    task: 'Engineer and benchmark Financial News Simplification Prompt with Anti-Hallucination Guardrails',
    epic: 'AI/LLM Processing',
    phase: 'Phase 3: AI/LLM',
    status: 'To Do',
    dependency: 'TSK-08',
    deliverable: 'Prompt engineering documentation and tested JSON schema template',
    description: 'Construct structured system prompt enforcing: plain English (Grade 8-9 readability), preserving exact numerical figures, separating facts from speculation.',
    acceptanceCriteria: ['Zero invented numbers or dates', 'Explicitly extracts financial jargon with definitions', 'Separates facts vs interpretations'],
    definitionOfDone: ['Evaluated against 5 diverse financial articles', 'Validates against Zod/JSON schema 100%']
  },
  {
    id: 'TSK-10',
    task: 'Implement "Why It Matters" Context Generator & Sentiment Analyzer',
    epic: 'AI/LLM Processing',
    phase: 'Phase 3: AI/LLM',
    status: 'To Do',
    dependency: 'TSK-09',
    deliverable: 'Structured analysis output generator with retail investor, consumer, and economic impacts',
    description: 'Generate 3 distinct perspectives for the ordinary person: how it impacts their wallet/bills, retirement/investments, and the macro economy.',
    acceptanceCriteria: ['Provides actionable consumer and retail investor context', 'Classifies sentiment with confidence score and justification'],
    definitionOfDone: ['Automated test verifies output format on sample earnings and Fed policy articles']
  },
  {
    id: 'TSK-11',
    task: 'Implement Entity Radar (Tickers, Companies, Regulators, Sectors) & Jargon Buster',
    epic: 'AI/LLM Processing',
    phase: 'Phase 3: AI/LLM',
    status: 'To Do',
    dependency: 'TSK-09',
    deliverable: 'Entity extraction parser and interactive financial glossary builder',
    description: 'Extract exact stock tickers, relevant regulatory bodies, affected market sectors, and key financial jargon with 1-sentence analogies.',
    acceptanceCriteria: ['Accurately detects tickers like $AAPL, $NVDA, SPY', 'Explains terms like "Hawkish", "Basis Points", "EBITDA" in plain language'],
    definitionOfDone: ['Tested on market wrap-up article with 5+ jargon terms']
  },

  // Phase 4: Backend
  {
    id: 'TSK-12',
    task: 'Design Database Schemas for Users, Articles, Summaries, Bookmarks, and History',
    epic: 'Database',
    phase: 'Phase 4: Backend',
    status: 'To Do',
    dependency: 'TSK-02',
    deliverable: 'SQL / SQLite / PostgreSQL DDL migration scripts and Prisma/TypeORM schema',
    description: 'Create normalized relational schema with primary keys, foreign keys, timestamps, indexes on articleUrl and userId.',
    acceptanceCriteria: ['Schema supports article caching to avoid repeated LLM calls', 'Bookmarks table enforces user_id + article_id uniqueness'],
    definitionOfDone: ['Migration applies cleanly on clean database', 'Relationships verified via ER diagram']
  },
  {
    id: 'TSK-13',
    task: 'Implement Article Summary Caching Layer to optimize cost and latency',
    epic: 'Backend Development',
    phase: 'Phase 4: Backend',
    status: 'To Do',
    dependency: 'TSK-11',
    deliverable: 'Summary service with cache-hit query before invoking LLM',
    description: 'Check DB for existing summary of the same article URL or hash before calling Gemini API. Reduces token usage by 85%.',
    acceptanceCriteria: ['Second request for same article responds in < 50ms from cache', 'New articles invoke LLM and cache result'],
    definitionOfDone: ['Cache hit/miss integration test passing']
  },
  {
    id: 'TSK-14',
    task: 'Build REST APIs: /api/news, /api/articles/:id, /api/summarize, /api/bookmarks',
    epic: 'Backend Development',
    phase: 'Phase 4: Backend',
    status: 'To Do',
    dependency: 'TSK-13',
    deliverable: 'Fully functional Express/FastAPI routes with request validation',
    description: 'Expose standardized RESTful endpoints with Zod request validation, HTTP status codes, and error envelopes.',
    acceptanceCriteria: ['Validates payload formats', 'Returns consistent error JSON { success: false, error: string }', 'Supports pagination & bookmark toggling'],
    definitionOfDone: ['Postman collection or API tests verify all 7 endpoints']
  },
  {
    id: 'TSK-15',
    task: 'Implement Lightweight User Session / Bookmark Storage Engine',
    epic: 'Backend Development',
    phase: 'Phase 4: Backend',
    status: 'To Do',
    dependency: 'TSK-14',
    deliverable: 'User identification via lightweight token or guest session with bookmark persistence',
    description: 'Support bookmarking and search history tracking for ordinary users with zero barrier to entry (guest session with optional login).',
    acceptanceCriteria: ['Users can save and retrieve saved articles', 'Search history logged with timestamps'],
    definitionOfDone: ['Verified bookmark add, list, delete cycle']
  },

  // Phase 5: Frontend
  {
    id: 'TSK-16',
    task: 'Build News Feed Dashboard with Live Category Tabs & Search Bar',
    epic: 'Frontend Development',
    phase: 'Phase 5: Frontend',
    status: 'To Do',
    dependency: 'TSK-04',
    deliverable: 'Responsive Feed UI with real-time category filtering and debounced search',
    description: 'Header with search input, category pill filters (All, Economy, Stocks, Crypto, Real Estate, Central Banks), and responsive grid.',
    acceptanceCriteria: ['Search is debounced (300ms)', 'Category click updates feed instantly', 'Clean card layout with source badges'],
    definitionOfDone: ['Renders smooth animations without UI jitter']
  },
  {
    id: 'TSK-17',
    task: 'Build Article Card Component with Sentiment Badges & One-Click Simplify CTA',
    epic: 'Frontend Development',
    phase: 'Phase 5: Frontend',
    status: 'To Do',
    dependency: 'TSK-16',
    deliverable: 'Interactive Article Card with thumbnail, source, date, and "Simplify This" action button',
    description: 'Card shows published time ago, reading time estimate, topic badge, and trigger button to open simplified view.',
    acceptanceCriteria: ['Clear visual hierarchy', 'Bookmark heart button with optimistic UI update', 'Loading spinner while fetching summary'],
    definitionOfDone: ['Card passes accessibility check with ARIA labels']
  },
  {
    id: 'TSK-18',
    task: 'Create Simplified Article Modal & Deep-Dive Drawer with Jargon Tooltips',
    epic: 'Frontend Development',
    phase: 'Phase 5: Frontend',
    status: 'To Do',
    dependency: 'TSK-17',
    deliverable: 'Rich modal displaying TL;DR, 3-bullet takeaway, Jargon Buster, and Why It Matters cards',
    description: 'Full-featured reader showing side-by-side or tabbed: "Original Wall St Jargon" vs "Simplified Plain English" with interactive glossary tooltips.',
    acceptanceCriteria: ['Jargon terms are highlighted with hover/click definitions', 'Why It Matters divided into Consumer & Investor tabs', 'Copy-to-clipboard button'],
    definitionOfDone: ['Tested on mobile, tablet, and desktop viewports']
  },
  {
    id: 'TSK-19',
    task: 'Develop Bookmarked Articles Page & Search History Drawer',
    epic: 'Frontend Development',
    phase: 'Phase 5: Frontend',
    status: 'To Do',
    dependency: 'TSK-18',
    deliverable: 'Saved Articles management view with filter by tag and remove capability',
    description: 'Allow users to review saved summaries offline, filter their personal reading list, and clear search history.',
    acceptanceCriteria: ['Shows list of bookmarked articles with cached summaries', 'User can remove bookmarks with undo toast', 'Empty state UI when no bookmarks'],
    definitionOfDone: ['Persists state in localStorage or database seamlessly']
  },
  {
    id: 'TSK-20',
    task: 'Implement Loading Skeletons, Error Boundary, and Offline Resilience Banner',
    epic: 'Frontend Development',
    phase: 'Phase 5: Frontend',
    status: 'To Do',
    dependency: 'TSK-19',
    deliverable: 'Smooth skeleton shimmer screens and user-friendly error fallback cards',
    description: 'Prevent white-screen crashes, display animated pulse placeholders during AI summarization (which takes 2-4 seconds), and provide retry buttons.',
    acceptanceCriteria: ['No abrupt layout shifts (CLS)', 'Meaningful error messages instead of raw stack traces', 'Retry button on failed API requests'],
    definitionOfDone: ['Lighthouse Accessibility and Best Practices score > 90']
  },

  // Phase 6: Testing
  {
    id: 'TSK-21',
    task: 'Write Backend Unit Tests for News Parser and Fallback Ingestion',
    epic: 'Testing',
    phase: 'Phase 6: Testing',
    status: 'To Do',
    dependency: 'TSK-14',
    deliverable: 'Jest / Vitest test suite with 100% pass rate for parser utilities',
    description: 'Test article normalization with truncated text, missing thumbnails, special characters, and duplicate URLs.',
    acceptanceCriteria: ['Covers edge cases: 0-length body, undefined author, null dates', 'Runs in CI/locally with npm test'],
    definitionOfDone: ['Tests pass cleanly without unhandled rejections']
  },
  {
    id: 'TSK-22',
    task: 'Write LLM Output Validation Tests & Hallucination Guardrail Checkers',
    epic: 'Testing',
    phase: 'Phase 6: Testing',
    status: 'To Do',
    dependency: 'TSK-11',
    deliverable: 'Automated test suite checking schema validity, number retention, and negative constraints',
    description: 'Ensure prompt responses strictly parse as valid JSON matching our Zod schema, verifying that numbers cited in summaries match the source article.',
    acceptanceCriteria: ['Catches malformed JSON gracefully', 'Fails if summary hallucinates percentages not in original article'],
    definitionOfDone: ['Automated suite runs against 5 benchmark golden test cases']
  },
  {
    id: 'TSK-23',
    task: 'Perform Frontend Component & End-to-End User Flow Tests',
    epic: 'Testing',
    phase: 'Phase 6: Testing',
    status: 'To Do',
    dependency: 'TSK-20',
    deliverable: 'Playwright or React Testing Library tests for Search -> Simplify -> Bookmark flow',
    description: 'Verify user can search "Federal Reserve", click "Simplify", see TL;DR within 4s, and click "Bookmark".',
    acceptanceCriteria: ['Key user journey succeeds from home to simplified view', 'Bookmark counter increments properly'],
    definitionOfDone: ['All integration test assertions pass']
  },

  // Phase 7: Deployment
  {
    id: 'TSK-24',
    task: 'Configure Production Environment Variables and Production Build Scripts',
    epic: 'Deployment',
    phase: 'Phase 7: Deployment',
    status: 'To Do',
    dependency: 'TSK-23',
    deliverable: 'vite.config.ts production optimization and server.ts static asset serving',
    description: 'Ensure backend serves compiled frontend build in production, single port execution, and gzip/brotli compression ready.',
    acceptanceCriteria: ['npm run build executes with 0 TypeScript errors', 'Single command npm run start runs full-stack app'],
    definitionOfDone: ['Production bundle verified locally with zero leaks of .env']
  },
  {
    id: 'TSK-25',
    task: 'Deploy Full-Stack App to Cloud Platform (Render / Railway / Vercel + Cloud Run)',
    epic: 'Deployment',
    phase: 'Phase 7: Deployment',
    status: 'To Do',
    dependency: 'TSK-24',
    deliverable: 'Live public HTTPS URL with healthy status check',
    description: 'Deploy web service, configure secret environment variables on the cloud dashboard, and configure custom domain or preview URL.',
    acceptanceCriteria: ['Public URL accessible worldwide on HTTPS', 'API calls route correctly with zero CORS blocks', 'Database persists across restarts'],
    definitionOfDone: ['Live URL smoke tested and confirmed responsive']
  },

  // Phase 8: Documentation & Demo
  {
    id: 'TSK-26',
    task: 'Write Production-Ready README.md with Setup, Architecture Diagram, and API Reference',
    epic: 'Documentation',
    phase: 'Phase 8: Documentation & Demo',
    status: 'To Do',
    dependency: 'TSK-25',
    deliverable: 'Comprehensive README.md in root directory with screenshots and badges',
    description: 'Document step-by-step setup, prerequisites, architecture flow, prompt engineering choices, and deployment instructions.',
    acceptanceCriteria: ['New developer can clone and run app within 5 minutes', 'Includes ASCII architecture diagram and sample curl commands'],
    definitionOfDone: ['Markdown renders cleanly on GitHub preview']
  },
  {
    id: 'TSK-27',
    task: 'Record and Produce 5-10 Minute Capstone Mentor Review Demo Video',
    epic: 'Documentation',
    phase: 'Phase 8: Documentation & Demo',
    status: 'To Do',
    dependency: 'TSK-26',
    deliverable: 'Video link (Loom / YouTube unlisted) following the 10-step mentor presentation script',
    description: 'Walk through problem statement, live working demo with real financial articles, architecture explanation, code highlights, and Kanban progression.',
    acceptanceCriteria: ['Duration between 5 and 10 minutes', 'Crisp audio and screen recording', 'Covers all 10 mentor rubric points'],
    definitionOfDone: ['Video submitted along with repository URL']
  },
  {
    id: 'TSK-28',
    task: 'Perform Final Capstone Submission Checklist Audit',
    epic: 'Documentation',
    phase: 'Phase 8: Documentation & Demo',
    status: 'To Do',
    dependency: 'TSK-27',
    deliverable: '100% completed Final Submission Checklist with all User Stories in Review status',
    description: 'Audit repository files, verify no sensitive keys were ever committed in git history, ensure all documentation is up to date.',
    acceptanceCriteria: ['All 14 checklist items verified', 'Zero exposed secrets in git log', 'Kanban board fully synchronized'],
    definitionOfDone: ['Ready for mentor evaluation and grading']
  }
];

export const USER_STORIES_DATA: UserStory[] = [
  {
    id: 'US-01',
    epic: 'News Data Integration',
    story: 'As a curious reader with no finance background, I want to browse a curated feed of today’s top financial headlines, so that I can stay informed about the economy without being overwhelmed.',
    acceptanceCriteria: [
      'Displays a grid/list of minimum 10 recent financial articles.',
      'Each card includes headline, publication source, timestamp, and estimated reading time.',
      'Categories include Markets, Economy, Tech & AI, Crypto, and Personal Finance.'
    ],
    priority: 'High',
    dependencies: 'TSK-06, TSK-07',
    definitionOfDone: ['Feed loads within 1.5 seconds', 'Handles network failure with friendly retry card', 'Unit test for news normalization passes'],
    suggestedKanbanStatus: 'To Do'
  },
  {
    id: 'US-02',
    epic: 'AI/LLM Processing',
    story: 'As an ordinary user, I want a 3-bullet plain English summary of any complex financial article, so that I can grasp the main takeaway in under 30 seconds without reading 2,000 words of Wall Street jargon.',
    acceptanceCriteria: [
      'Summary is max 3 concise bullet points written at an 8th-grade reading level.',
      'All specific figures, percentages, dates, and names match the source article exactly.',
      'Zero invented data or unsupported speculation.'
    ],
    priority: 'High',
    dependencies: 'TSK-08, TSK-09',
    definitionOfDone: ['LLM output conforms to JSON schema', 'Tested on 10 diverse articles without hallucination', 'Summarization response time under 4 seconds'],
    suggestedKanbanStatus: 'To Do'
  },
  {
    id: 'US-03',
    epic: 'AI/LLM Processing',
    story: 'As a young professional planning my savings, I want a "Why It Matters" section that explains how this news impacts my personal wallet, mortgage, or grocery bills, so that I understand real-world relevance.',
    acceptanceCriteria: [
      'Provides three distinct perspective callouts: (1) Everyday Consumer Impact, (2) Retail Investor Impact, (3) Macro Economy.',
      'Clear, practical language explaining interest rates, inflation, or company shifts in terms of everyday spending and borrowing.'
    ],
    priority: 'High',
    dependencies: 'TSK-10',
    definitionOfDone: ['Component renders tabs/cards for each impact category', 'Includes visual icons for Consumer, Investor, and Macro'],
    suggestedKanbanStatus: 'To Do'
  },
  {
    id: 'US-04',
    epic: 'AI/LLM Processing',
    story: 'As a novice investor, I want difficult financial terms (e.g. "Hawkish pause", "Basis points", "Yield curve inversion") highlighted and explained with simple analogies, so that I learn financial vocabulary as I read.',
    acceptanceCriteria: [
      'Identifies top 2 to 5 complex jargon terms in the article.',
      'Provides a 1-sentence plain-language definition with a relatable everyday analogy.',
      'Interactive UI allows tapping/hovering over terms to read the definition.'
    ],
    priority: 'High',
    dependencies: 'TSK-11, TSK-18',
    definitionOfDone: ['Glossary / Jargon Buster component renders in summary modal', 'Accordion or tooltip interaction works on mobile'],
    suggestedKanbanStatus: 'To Do'
  },
  {
    id: 'US-05',
    epic: 'Frontend Development',
    story: 'As a user searching for specific topics, I want to filter news by categories and search for companies or keywords (e.g., "Apple", "Federal Reserve", "Bitcoin"), so that I find news relevant to my interests.',
    acceptanceCriteria: [
      'Search input filters articles by title, description, and tags in real time.',
      'Category pills toggle instant filtering.',
      'Clear indicator when 0 articles match, with a button to reset filters.'
    ],
    priority: 'Medium',
    dependencies: 'TSK-07, TSK-16',
    definitionOfDone: ['Debounced search prevents laggy UI', 'URL query string or state updates seamlessly'],
    suggestedKanbanStatus: 'To Do'
  },
  {
    id: 'US-06',
    epic: 'Backend Development',
    story: 'As a user, I want to bookmark simplified articles so that I can revisit important financial insights later from my personal reading list.',
    acceptanceCriteria: [
      'Bookmark button on each article card and inside the detailed summary view.',
      'Bookmarked tab displays all saved items with their cached simplified summaries.',
      'Ability to remove bookmarks with instant UI feedback.'
    ],
    priority: 'Medium',
    dependencies: 'TSK-14, TSK-15, TSK-19',
    definitionOfDone: ['Bookmarks persist in database/local storage across page reloads', 'Optimistic UI update provides zero lag feedback'],
    suggestedKanbanStatus: 'To Do'
  },
  {
    id: 'US-07',
    epic: 'AI/LLM Processing',
    story: 'As a user concerned about fake news and bias, I want to see a clear distinction between verified facts and market speculation/analyst opinions, so that I am not misled by hype.',
    acceptanceCriteria: [
      'AI response includes two dedicated sections: "Verified Facts" and "Market Interpretations / Speculation".',
      'Facts reference verified company or government numbers; Interpretations quote analyst predictions.',
      'Clear visual pill tag: "AI-Generated Analysis - For Educational Purposes Only".'
    ],
    priority: 'High',
    dependencies: 'TSK-09, TSK-18',
    definitionOfDone: ['Disclaimer banner visible on every simplified article', 'Fact vs Opinion grid styled with distinct color accents'],
    suggestedKanbanStatus: 'To Do'
  }
];

export const SAMPLE_ARTICLES: ArticleSample[] = [
  {
    id: 'art-01',
    title: 'Federal Reserve Cuts Benchmark Interest Rate by 50 Basis Points Amid Cooling Labor Market',
    source: 'Financial Times / Reuters',
    publishedAt: '2 hours ago',
    category: 'Central Banks & Economy',
    ticker: 'FED / USD',
    rawText: `WASHINGTON — The Federal Open Market Committee (FOMC) on Wednesday concluded its two-day monetary policy symposium by voting 11-to-1 to lower the target range for the federal funds rate by 50 basis points to 4.75%–5.00%. The outsized reduction marks the central bank's first rate cut in more than four years, shifting its dual-mandate focus from curbing post-pandemic demand-pull inflation toward insulating a moderating nonfarm payrolls trajectory.\n\nFed Chair Jerome Powell emphasized that the committee does not perceive elevated recessionary probabilities, characterizing the 50 bps recalibration as a prophylactic measure to sustain macroeconomic equilibrium as headline Personal Consumption Expenditures (PCE) inflation converged to 2.2% year-over-year. The dot plot dot-distribution signaled an additional 50 bps of easing across the November and December gatherings, with quantitative tightening (QT) continuing unabated via the scheduled balance sheet runoff of up to $25 billion in U.S. Treasuries and $35 billion in agency mortgage-backed securities per month. Equity indices rallied in afternoon trading, with the S&P 500 gaining 1.4% and the benchmark 10-year Treasury yield slipping 6 basis points to 3.65%.`,
    simplified: {
      tldr: 'The Federal Reserve lowered its key interest rate by 0.50% (50 basis points)—the first cut in over four years—making borrowing money for houses, cars, and credit cards cheaper as inflation cools down.',
      keyPoints: [
        'The Fed dropped interest rates from ~5.3% down to 4.75%–5.00% to protect jobs as hiring slows.',
        'Inflation has dropped from over 9% down to 2.2%, very close to the Fed’s healthy 2% target.',
        'Officials plan two more smaller rate cuts before the year ends, meaning borrowing costs will likely continue easing.'
      ],
      sentiment: {
        label: 'Bullish / Positive',
        score: 0.82,
        rationale: 'Lower borrowing costs stimulate business investment, lower consumer debt pressure, and historically support stock market growth.'
      },
      whyItMatters: {
        retailInvestors: 'Cheaper borrowing usually boosts stock valuations (especially tech and growth companies) because businesses pay less interest on loans and consumers spend more.',
        consumers: 'Mortgage rates, auto loans, and variable credit card APRs will gradually become cheaper. However, interest earned on high-yield savings accounts and CDs will begin dropping.',
        broaderEconomy: 'Prevents the slowing economy from sliding into a recession while cementing the win over high post-COVID inflation.'
      },
      jargonBuster: [
        {
          term: '50 Basis Points (bps)',
          simpleExplanation: 'In finance, 100 basis points equals 1 percentage point. So 50 basis points simply means 0.50%.'
        },
        {
          term: 'Federal Funds Rate',
          simpleExplanation: 'The master interest rate set by the government central bank that controls what banks charge each other to borrow money overnight.'
        },
        {
          term: 'Prophylactic Rate Cut',
          simpleExplanation: 'A preventative measure taken early to prevent problems (like mass layoffs) before they actually happen.'
        },
        {
          term: 'Quantitative Tightening (QT)',
          simpleExplanation: 'When the central bank shrinks its investments to pull excess cash out of the banking system.'
        }
      ],
      entities: {
        companies: ['Federal Reserve', 'S&P 500', 'FOMC'],
        sectors: ['Banking', 'Housing & Real Estate', 'Treasuries'],
        tickers: ['SPY', 'TLT', 'USD'],
        metrics: ['50 bps cut', '4.75%–5.00% target rate', '2.2% PCE inflation', '10-yr Treasury at 3.65%']
      },
      factsVsInterpretation: {
        facts: [
          'The FOMC voted 11-1 to lower rates by 50 basis points to 4.75%–5.00%.',
          'PCE inflation reached 2.2% year-over-year.',
          'The S&P 500 rose 1.4% following the announcement.'
        ],
        interpretations: [
          'Fed officials believe a 50 bps cut will successfully avoid a recession (preventative soft landing).',
          'Market participants project two additional rate reductions before the calendar year closes.'
        ]
      },
      risksAndUncertainties: [
        'If inflation suddenly surges back up due to oil price shocks, the Fed may have to pause rate cuts.',
        'High-yield savings account yields will decline from 5% towards 4% over the next several quarters.'
      ]
    }
  },
  {
    id: 'art-02',
    title: 'Nvidia Unveils Next-Gen AI Chip Architecture; Reports 122% Year-Over-Year Revenue Surge',
    source: 'Wall Street Journal',
    publishedAt: '5 hours ago',
    category: 'Technology & AI',
    ticker: 'NVDA / Nasdaq',
    rawText: `SANTA CLARA — Semiconductor titan Nvidia Corp. (NASDAQ: NVDA) reported fiscal second-quarter non-GAAP earnings per diluted share of $0.68, beating consensus estimates of $0.64, driven by unprecedented hyperscaler demand for its Blackwell B200 tensor-core graphic processing units. Net revenue vaulted 122% year-over-year to a record $30.04 billion, with Data Center revenue specifically accounting for $26.3 billion of the top-line haul.\n\nGross margin expanded 430 basis points to 75.1%, though management signaled sequential margin compression in Q3 to 74.4% as early-stage production ramp packaging yields normalize with foundry partner TSMC. CEO Jensen Huang rebuffed rumors of engineering thermal throttling on CoWoS-L packaging, stating engineering revisions were completed and production output will deliver multiple billions in revenue during Q4. Despite the blowout print, shares dipped 2.1% in extended trading on astronomical buy-side whisper numbers and supply chain bottleneck anxieties.`,
    simplified: {
      tldr: 'Nvidia blew away Wall Street expectations by doubling its sales to $30 billion in three months, powered by massive demand for artificial intelligence computing chips from companies like Microsoft, Google, and Meta.',
      keyPoints: [
        'Nvidia made $30.04 billion in three months—up 122% compared to the exact same period last year.',
        'Over 87% of its sales came directly from high-end AI data center processors.',
        'Even though the company crushed expectations, the stock dipped 2% after hours because investors had unrealistically sky-high expectations.'
      ],
      sentiment: {
        label: 'Bullish / Positive',
        score: 0.78,
        rationale: 'Strongest fundamental balance sheet and revenue growth in big tech; supply constraints rather than lack of demand are the only bottleneck.'
      },
      whyItMatters: {
        retailInvestors: 'Nvidia is one of the world\'s most valuable companies; its stock performance heavily influences the entire S&P 500 and tech index funds like QQQ held in millions of 401(k) accounts.',
        consumers: 'Big tech companies are investing billions into infrastructure that powers tools like AI search engines, voice assistants, and medical research algorithms.',
        broaderEconomy: 'AI infrastructure spending is currently one of the primary engines propelling corporate capital expenditure and semiconductor manufacturing worldwide.'
      },
      jargonBuster: [
        {
          term: 'Hyperscalers',
          simpleExplanation: 'Huge cloud computing giants like Amazon AWS, Microsoft Azure, and Google Cloud that buy tens of thousands of computer chips at once.'
        },
        {
          term: 'Gross Margin (75.1%)',
          simpleExplanation: 'How much money is left over after the direct cost of making the chip. For every $100 Nvidia sells, $75 is pure gross profit.'
        },
        {
          term: 'Whisper Numbers',
          simpleExplanation: 'Unofficial, super-optimistic profit targets passed around privately by Wall Street traders that are even higher than official forecasts.'
        },
        {
          term: 'Foundry Partner (TSMC)',
          simpleExplanation: 'A specialized mega-factory that physically prints and manufactures the computer microchips that Nvidia designs on paper.'
        }
      ],
      entities: {
        companies: ['Nvidia Corp.', 'TSMC', 'Microsoft', 'Alphabet'],
        sectors: ['Semiconductors', 'Artificial Intelligence', 'Cloud Computing'],
        tickers: ['NVDA', 'TSM', 'QQQ'],
        metrics: ['$30.04B revenue', '122% YoY increase', '$0.68 EPS vs $0.64 est', '75.1% gross margin']
      },
      factsVsInterpretation: {
        facts: [
          'Revenue was $30.04 billion (up 122% YoY).',
          'Data Center accounted for $26.3 billion.',
          'Gross margin reached 75.1%.'
        ],
        interpretations: [
          'The small stock decline was caused by unrealistic whisper numbers and packaging yield anxieties.',
          'Management claims chip design issues are completely solved and Q4 will see multi-billion dollar deliveries.'
        ]
      },
      risksAndUncertainties: [
        'Reliance on a single manufacturer (TSMC in Taiwan) introduces geopolitical and production bottleneck risks.',
        'If cloud companies do not see sufficient revenue from AI products, their spending on Nvidia chips could decelerate in 2026.'
      ]
    }
  },
  {
    id: 'art-03',
    title: 'Treasury Yield Curve Un-Inverts After Historic 783 Consecutive Days in Deep Inversion',
    source: 'Bloomberg Markets',
    publishedAt: '8 hours ago',
    category: 'Bond Markets & Macro',
    ticker: '2Y / 10Y UST',
    rawText: `NEW YORK — The benchmark spread between the U.S. 2-year and 10-year Treasury yields widened past parity on Monday, dis-inverting the sovereign debt curve after an unprecedented 783 trading sessions in negative territory. The 10-year note yield settled at 3.76% while the policy-sensitive 2-year yield slid to 3.74%, generating a positive 2-basis-point slope.\n\nHistorically, the 2s10s yield curve is an esteemed harbinger of cyclical contractions, having reliably preceded every modern domestic recession since 1955 with minimal false positives. However, cross-asset analysts observe that the true macroeconomic inflection occurs not during the initial inversion, but during the "bull un-inversion" phase, wherein front-end yields collapse rapidly under anticipation of imminent emergency monetary accommodation. Portfolio managers are actively rebalancing duration profiles, paring equity beta in anticipation of corporate margin compression and sovereign refinancing headwinds.`,
    simplified: {
      tldr: 'For over two years, short-term government bonds paid higher interest than long-term bonds (an unnatural signal called an "inverted yield curve"). Now, normal conditions have returned—which historically signals the final countdown to whether a recession happens or is avoided.',
      keyPoints: [
        'A normal bond market pays higher interest if you lock your money up for 10 years compared to 2 years.',
        'For 783 days, that was flipped backwards because markets were terrified of rapid inflation and interest rate hikes.',
        'Now the 10-year yield (3.76%) is higher than the 2-year yield (3.74%), returning the market to normal.'
      ],
      sentiment: {
        label: 'Neutral / Mixed',
        score: 0.51,
        rationale: 'While returning to normal is healthy, past economic history shows that recessions frequently happen right around the time the curve un-inverts.'
      },
      whyItMatters: {
        retailInvestors: 'Historically, the stock market can be volatile during the first 6–12 months after an un-inversion. Keeping an emergency fund and a diversified portfolio is prudent.',
        consumers: 'Banks become more willing to lend money when the curve is normal because they make profit by borrowing short-term and lending long-term (like 30-year mortgages).',
        broaderEconomy: 'This is the most watched economic barometer in modern history. The next 6 months will prove whether the US pulls off a rare "soft landing" without mass layoffs.'
      },
      jargonBuster: [
        {
          term: 'Yield Curve',
          simpleExplanation: 'A chart showing how much interest government bonds pay across different timeframes (3 months, 2 years, 10 years, 30 years).'
        },
        {
          term: 'Inverted Yield Curve',
          simpleExplanation: 'An unusual situation where lending money to the government for just 2 years pays MORE interest than lending it for 10 years. It means investors expect bad economic news ahead.'
        },
        {
          term: 'Bull Un-Inversion',
          simpleExplanation: 'When the curve returns to normal because short-term interest rates fall fast as central banks prepare to cut rates.'
        },
        {
          term: 'Duration Profile',
          simpleExplanation: 'A measurement of how sensitive a bond portfolio is to changes in interest rates.'
        }
      ],
      entities: {
        companies: ['U.S. Department of the Treasury', 'Wall Street Bond Desks'],
        sectors: ['Fixed Income / Bonds', 'Banking & Credit Markets'],
        tickers: ['US2Y', 'US10Y', 'BND'],
        metrics: ['783 consecutive days', '10-yr yield at 3.76%', '2-yr yield at 3.74%', '+2 bps spread']
      },
      factsVsInterpretation: {
        facts: [
          'The 2-year and 10-year yield spread remained inverted for 783 trading sessions.',
          'The 10-year yield reached 3.76% and the 2-year reached 3.74% on Monday.'
        ],
        interpretations: [
          'Analysts debate whether this un-inversion signals an impending recession or a successful economic soft landing.',
          'Fund managers are adjusting their bond holdings based on assumptions about upcoming corporate earnings.'
        ]
      },
      risksAndUncertainties: [
        'In past cycles (1990, 2001, 2007), a recession began within 3 to 12 months after the curve un-inverted.',
        'However, if consumer spending and jobs hold firm, this could be an exception like 1995.'
      ]
    }
  }
];

export const DATABASE_TABLES_DATA: DatabaseTable[] = [
  {
    name: 'users',
    description: 'Stores user profile, authentication references, and personalization preferences.',
    fields: [
      { name: 'id', type: 'VARCHAR(36)', description: 'Unique UUID identifier', isPk: true },
      { name: 'email', type: 'VARCHAR(255)', description: 'User email address (unique)', nullable: false },
      { name: 'display_name', type: 'VARCHAR(100)', description: 'Public or account name', nullable: true },
      { name: 'preferred_reading_level', type: 'VARCHAR(30)', description: 'e.g. "beginner", "intermediate", "bullet_points"', nullable: false },
      { name: 'created_at', type: 'TIMESTAMP', description: 'Account creation timestamp', nullable: false },
      { name: 'updated_at', type: 'TIMESTAMP', description: 'Last profile update timestamp', nullable: false }
    ]
  },
  {
    name: 'articles',
    description: 'Raw ingested financial news articles collected from external News APIs / RSS.',
    fields: [
      { name: 'id', type: 'VARCHAR(36)', description: 'Unique article UUID', isPk: true },
      { name: 'title', type: 'VARCHAR(500)', description: 'Original article headline', nullable: false },
      { name: 'source_name', type: 'VARCHAR(150)', description: 'e.g. Bloomberg, Reuters, WSJ', nullable: false },
      { name: 'source_url', type: 'TEXT', description: 'Original canonical URL of the article (unique)', nullable: false },
      { name: 'url_hash', type: 'VARCHAR(64)', description: 'SHA-256 hash of URL for instant unique lookup', nullable: false },
      { name: 'author', type: 'VARCHAR(150)', description: 'Journalist or wire service byline', nullable: true },
      { name: 'category', type: 'VARCHAR(50)', description: 'Category: Markets, Economy, Tech, Crypto', nullable: false },
      { name: 'raw_content', type: 'TEXT', description: 'Cleaned raw text / body of the news article', nullable: false },
      { name: 'image_url', type: 'TEXT', description: 'Lead banner image URL if available', nullable: true },
      { name: 'published_at', type: 'TIMESTAMP', description: 'Article original publication time', nullable: false },
      { name: 'created_at', type: 'TIMESTAMP', description: 'Time record was ingested into system', nullable: false }
    ]
  },
  {
    name: 'summaries',
    description: 'Cached AI-generated simplified breakdowns and analyses to avoid re-running LLM.',
    fields: [
      { name: 'id', type: 'VARCHAR(36)', description: 'Unique summary UUID', isPk: true },
      { name: 'article_id', type: 'VARCHAR(36)', description: 'References articles.id', isFk: true, refTable: 'articles', nullable: false },
      { name: 'tldr', type: 'TEXT', description: '1-sentence high-level summary in plain English', nullable: false },
      { name: 'key_points', type: 'JSONB / TEXT', description: 'Array of 3 digestible takeaways', nullable: false },
      { name: 'why_it_matters', type: 'JSONB / TEXT', description: 'Structured JSON: consumer, retailInvestor, macro', nullable: false },
      { name: 'jargon_buster', type: 'JSONB / TEXT', description: 'Array of objects: { term, simpleExplanation }', nullable: false },
      { name: 'entities', type: 'JSONB / TEXT', description: 'Extracted companies, tickers, sectors, metrics', nullable: false },
      { name: 'sentiment_label', type: 'VARCHAR(30)', description: 'Bullish, Bearish, or Neutral', nullable: false },
      { name: 'sentiment_score', type: 'FLOAT', description: 'Confidence score from 0.00 to 1.00', nullable: false },
      { name: 'facts_vs_interpretation', type: 'JSONB / TEXT', description: 'Separated verified facts vs analyst speculation', nullable: false },
      { name: 'model_used', type: 'VARCHAR(60)', description: 'e.g. gemini-2.5-flash', nullable: false },
      { name: 'created_at', type: 'TIMESTAMP', description: 'Generation timestamp', nullable: false }
    ]
  },
  {
    name: 'bookmarks',
    description: 'User saved articles for personal reading lists and offline review.',
    fields: [
      { name: 'id', type: 'VARCHAR(36)', description: 'Unique bookmark UUID', isPk: true },
      { name: 'user_id', type: 'VARCHAR(36)', description: 'References users.id', isFk: true, refTable: 'users', nullable: false },
      { name: 'article_id', type: 'VARCHAR(36)', description: 'References articles.id', isFk: true, refTable: 'articles', nullable: false },
      { name: 'notes', type: 'TEXT', description: 'Optional personal note written by user', nullable: true },
      { name: 'created_at', type: 'TIMESTAMP', description: 'Time bookmark was added', nullable: false }
    ]
  },
  {
    name: 'search_history',
    description: 'Tracks recent user search queries for search suggestions and analytics.',
    fields: [
      { name: 'id', type: 'VARCHAR(36)', description: 'Unique search entry UUID', isPk: true },
      { name: 'user_id', type: 'VARCHAR(36)', description: 'References users.id (nullable for guests)', isFk: true, refTable: 'users', nullable: true },
      { name: 'query_text', type: 'VARCHAR(255)', description: 'Search term entered (e.g. "Fed rate cut")', nullable: false },
      { name: 'category_filter', type: 'VARCHAR(50)', description: 'Category active during search', nullable: true },
      { name: 'result_count', type: 'INT', description: 'Number of articles returned', nullable: false },
      { name: 'searched_at', type: 'TIMESTAMP', description: 'Timestamp of query', nullable: false }
    ]
  },
  {
    name: 'categories',
    description: 'Lookup table of available news categories with icon and badge metadata.',
    fields: [
      { name: 'id', type: 'VARCHAR(50)', description: 'Primary slug e.g. "markets", "economy"', isPk: true },
      { name: 'label', type: 'VARCHAR(100)', description: 'Display name e.g. "Stock Markets"', nullable: false },
      { name: 'description', type: 'VARCHAR(255)', description: 'Short description of what falls under category', nullable: true },
      { name: 'icon_name', type: 'VARCHAR(50)', description: 'Lucide icon identifier', nullable: false }
    ]
  }
];

export const API_ENDPOINTS_DATA: ApiEndpoint[] = [
  {
    method: 'GET',
    endpoint: '/api/news',
    purpose: 'Retrieve paginated list of financial news articles with optional filters',
    authRequired: false,
    requestParamsOrBody: `Query parameters:\n?category=economy&search=interest%20rates&page=1&limit=10`,
    responseStructure: `{
  "success": true,
  "data": {
    "articles": [
      {
        "id": "art-01",
        "title": "Federal Reserve Cuts Benchmark Rate...",
        "sourceName": "Reuters",
        "category": "economy",
        "publishedAt": "2026-09-29T14:30:00Z",
        "hasSummary": true
      }
    ],
    "pagination": { "page": 1, "limit": 10, "total": 48, "totalPages": 5 }
  }
}`
  },
  {
    method: 'GET',
    endpoint: '/api/articles/:id',
    purpose: 'Fetch full original details and cached summary of a single article',
    authRequired: false,
    requestParamsOrBody: `Path parameter:\n:id = "art-01"`,
    responseStructure: `{
  "success": true,
  "data": {
    "article": { ... },
    "summary": { ... } // null if not yet simplified
  }
}`
  },
  {
    method: 'POST',
    endpoint: '/api/summarize',
    purpose: 'Trigger or fetch AI simplification for an article (uses DB cache when available)',
    authRequired: false,
    requestParamsOrBody: `{
  "articleId": "art-01",
  "forceRefresh": false,
  "readingLevel": "beginner"
}`,
    responseStructure: `{
  "success": true,
  "cached": true,
  "data": {
    "tldr": "The Federal Reserve lowered its key interest rate by 0.50%...",
    "keyPoints": [ ... ],
    "whyItMatters": { "consumer": "...", "retailInvestor": "...", "macro": "..." },
    "jargonBuster": [ { "term": "50 Basis Points", "simpleExplanation": "..." } ],
    "sentiment": { "label": "Bullish", "score": 0.82 },
    "factsVsInterpretation": { "facts": [ ... ], "interpretations": [ ... ] }
  }
}`
  },
  {
    method: 'GET',
    endpoint: '/api/bookmarks',
    purpose: 'Retrieve all saved articles for the authenticated or guest user',
    authRequired: false,
    requestParamsOrBody: `Headers:\nAuthorization: Bearer <token> (or x-guest-session-id)`,
    responseStructure: `{
  "success": true,
  "data": {
    "bookmarks": [
      {
        "id": "bmk-01",
        "articleId": "art-01",
        "title": "Federal Reserve Cuts...",
        "savedAt": "2026-09-29T15:00:00Z",
        "summary": { "tldr": "..." }
      }
    ]
  }
}`
  },
  {
    method: 'POST',
    endpoint: '/api/bookmarks',
    purpose: 'Save an article to the user’s personal bookmark list',
    authRequired: false,
    requestParamsOrBody: `{
  "articleId": "art-01",
  "notes": "Important for mortgage refi decision in November"
}`,
    responseStructure: `{
  "success": true,
  "message": "Article bookmarked successfully",
  "bookmarkId": "bmk-01"
}`
  },
  {
    method: 'DELETE',
    endpoint: '/api/bookmarks/:id',
    purpose: 'Remove an article from saved bookmarks',
    authRequired: false,
    requestParamsOrBody: `Path parameter: :id = "bmk-01"`,
    responseStructure: `{
  "success": true,
  "message": "Bookmark removed"
}`
  },
  {
    method: 'GET',
    endpoint: '/api/search/history',
    purpose: 'Get recent search queries performed by user',
    authRequired: false,
    requestParamsOrBody: `Query parameters: ?limit=5`,
    responseStructure: `{
  "success": true,
  "data": {
    "history": [
      { "query": "Nvidia earnings", "timestamp": "2026-09-29T12:00:00Z", "resultsCount": 14 }
    ]
  }
}`
  }
];

export const PROMPTS_DATA: PromptTemplate[] = [
  {
    id: 'p-01',
    title: '1. Financial News Simplification Prompt',
    purpose: 'Converts dense financial journalism into an 8th-grade reading level TL;DR and 3 key takeaways while retaining exact figures.',
    systemPrompt: `You are an expert financial journalist and plain-language educator. Your role is to explain complex financial news to ordinary citizens, beginner retail investors, and everyday consumers who have no specialized background in economics or finance.

RULES:
1. Accuracy: Never hallucinate, extrapolate, or invent figures, dates, percentages, or company announcements.
2. Number Fidelity: Preserve all exact dollar amounts, basis points, interest rates, and calendar dates mentioned in the original text.
3. Tone: Informative, balanced, objective, and accessible (target Grade 8-9 Flesch-Kincaid readability).
4. No Buzzwords: Avoid unexplained jargon such as "hawkish", "EBITDA", "basis points", "contango", or "quantitative easing". If a term is essential, define it immediately in simple words.
5. Strict JSON Output: Output strictly valid JSON matching the schema provided.`,
    userPromptTemplate: `Please simplify the following financial news article:

ARTICLE TITLE: {{title}}
ARTICLE SOURCE: {{source}}
ARTICLE TEXT:
"""
{{article_text}}
"""

Return a JSON object with this exact structure:
{
  "tldr": "A 1-to-2 sentence plain-language summary answering: What happened and why does it matter?",
  "key_points": [
    "First crucial fact with exact numbers and dates.",
    "Second key takeaway.",
    "Third key takeaway."
  ]
}`,
    jsonOutputSchema: `{
  "type": "object",
  "properties": {
    "tldr": { "type": "string" },
    "key_points": { "type": "array", "items": { "type": "string" }, "minItems": 3, "maxItems": 3 }
  },
  "required": ["tldr", "key_points"]
}`,
    safeguards: [
      'Reject any article text under 50 words as insufficient data.',
      'Check output numbers with a regex scanner against source article to detect numerical hallucinations.',
      'Never include speculative investment advice ("You should buy stock X").'
    ]
  },
  {
    id: 'p-02',
    title: '2. Financial Jargon Buster Prompt',
    purpose: 'Extracts dense financial buzzwords from the text and generates 1-sentence analogies understandable by high schoolers.',
    systemPrompt: `You are a financial literacy coach. Your mission is to demystify Wall Street jargon and empower ordinary people with clear mental models.

RULES:
- Extract between 2 and 5 technical terms present in the article.
- Provide a simple 1-to-2 sentence explanation for each term.
- Include a real-world, everyday analogy (e.g. comparing the Fed interest rate to the thermostat of an economy).
- Avoid circular definitions (do not define "inflation" as "the rate at which prices inflate").`,
    userPromptTemplate: `Analyze this financial news article and extract the top jargon terms:

ARTICLE:
"""
{{article_text}}
"""

Return JSON in this structure:
{
  "jargon_buster": [
    {
      "term": "Exact financial term (e.g., Basis Points)",
      "simple_explanation": "Plain English definition without financial jargon.",
      "everyday_analogy": "A relatable real-world comparison."
    }
  ]
}`,
    jsonOutputSchema: `{
  "type": "object",
  "properties": {
    "jargon_buster": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "term": { "type": "string" },
          "simple_explanation": { "type": "string" },
          "everyday_analogy": { "type": "string" }
        },
        "required": ["term", "simple_explanation", "everyday_analogy"]
      }
    }
  },
  "required": ["jargon_buster"]
}`,
    safeguards: [
      'Ensure terms actually appear in the article.',
      'Discard overly common words (e.g. "Money", "Bank", "Company") to focus on genuine jargon.'
    ]
  },
  {
    id: 'p-03',
    title: '3. "Why This Matters" Real-World Relevance Prompt',
    purpose: 'Translates macroeconomic and corporate announcements into tangible impacts for everyday consumers, retail investors, and the economy.',
    systemPrompt: `You are a practical personal finance economist. You answer the question every normal person asks when reading the news: "Why should I care about this?"

Divide your analysis strictly into three distinct perspectives:
1. Everyday Consumer: Impact on groceries, mortgage rates, credit card debt, car loans, or job security.
2. Retail Investor: Impact on index funds, 401(k) retirement accounts, tech stocks, or bonds.
3. Broader Economy: Long-term health of business investment, GDP, and inflation.`,
    userPromptTemplate: `Analyze this news and explain why it matters to normal people:

ARTICLE:
"""
{{article_text}}
"""

Output JSON:
{
  "why_it_matters": {
    "everyday_consumer": "Plain explanation of direct impact on living costs or wallet.",
    "retail_investor": "Plain explanation of impact on retirement savings and stock/bond portfolios.",
    "broader_economy": "Plain explanation of nationwide or global economic direction."
  }
}`,
    jsonOutputSchema: `{
  "type": "object",
  "properties": {
    "why_it_matters": {
      "type": "object",
      "properties": {
        "everyday_consumer": { "type": "string" },
        "retail_investor": { "type": "string" },
        "broader_economy": { "type": "string" }
      },
      "required": ["everyday_consumer", "retail_investor", "broader_economy"]
    }
  },
  "required": ["why_it_matters"]
}`,
    safeguards: [
      'Maintain neutrality; never promise guaranteed financial returns.',
      'Explicitly state if an event has minimal direct consumer impact.'
    ]
  },
  {
    id: 'p-04',
    title: '4. Sentiment & Market Mood Analysis Prompt',
    purpose: 'Classifies the sentiment of the news (Bullish, Bearish, or Neutral) with confidence score and factual rationale.',
    systemPrompt: `You are a quantitative financial sentiment analyst. Evaluate whether the news represents a favorable (bullish), unfavorable (bearish), or balanced/uncertain (neutral) development for the referenced assets or markets.

Provide a confidence score from 0.00 to 1.00 and articulate a factual rationale.`,
    userPromptTemplate: `Analyze the sentiment of the following article:

ARTICLE:
"""
{{article_text}}
"""

Output JSON:
{
  "sentiment": {
    "label": "Bullish / Positive" | "Bearish / Negative" | "Neutral / Mixed",
    "score": 0.85,
    "rationale": "Clear 2-sentence rationale summarizing the sentiment driver."
  }
}`,
    jsonOutputSchema: `{
  "type": "object",
  "properties": {
    "sentiment": {
      "type": "object",
      "properties": {
        "label": { "type": "string", "enum": ["Bullish / Positive", "Bearish / Negative", "Neutral / Mixed"] },
        "score": { "type": "number", "minimum": 0, "maximum": 1 },
        "rationale": { "type": "string" }
      },
      "required": ["label", "score", "rationale"]
    }
  },
  "required": ["sentiment"]
}`,
    safeguards: [
      'Do not conflate sensational headline clicks with actual underlying fundamentals.',
      'Default to Neutral / Mixed if equal upside and downside indicators exist.'
    ]
  },
  {
    id: 'p-05',
    title: '5. Facts vs. Interpretation & Risk Extraction Prompt',
    purpose: 'Safeguards users against speculation by strictly bifurcating verified hard numbers from analyst predictions or opinions.',
    systemPrompt: `You are a forensic financial fact-checker. Financial articles routinely mix hard factual data (audited earnings, enacted interest rates, official government statistics) with subjective interpretations (analyst price targets, CEO optimism, speculative rumors).

Your job is to strictly isolate verified facts from forward-looking opinions and highlight any prominent uncertainties.`,
    userPromptTemplate: `Separate facts from interpretations in this article:

ARTICLE:
"""
{{article_text}}
"""

Output JSON:
{
  "verified_facts": [
    "List only verified past or present actions and official numbers."
  ],
  "market_interpretations": [
    "List analyst predictions, speculative expectations, or CEO opinions."
  ],
  "risks_and_uncertainties": [
    "Specific risks or open questions mentioned in the text."
  ]
}`,
    jsonOutputSchema: `{
  "type": "object",
  "properties": {
    "verified_facts": { "type": "array", "items": { "type": "string" } },
    "market_interpretations": { "type": "array", "items": { "type": "string" } },
    "risks_and_uncertainties": { "type": "array", "items": { "type": "string" } }
  },
  "required": ["verified_facts", "market_interpretations", "risks_and_uncertainties"]
}`,
    safeguards: [
      'Any sentence containing words like "might", "expected", "could", "projected", "believes" belongs under interpretations.',
      'Numbers from official filings belong strictly under verified facts.'
    ]
  },
  {
    id: 'p-06',
    title: '6. Entity Radar & Financial Metadata Extractor Prompt',
    purpose: 'Extracts structured entities: company names, stock tickers, regulatory agencies, market sectors, and key metrics.',
    systemPrompt: `You are an automated financial knowledge graph parser. Extract all relevant commercial and macroeconomic entities from the text into standardized lists.`,
    userPromptTemplate: `Extract all financial entities from this text:

ARTICLE:
"""
{{article_text}}
"""

Output JSON:
{
  "entities": {
    "companies": ["List of official corporation names"],
    "tickers": ["Stock or currency tickers e.g. NVDA, AAPL, USD"],
    "sectors": ["Affected industries e.g. Semiconductors, Banking"],
    "regulators_and_institutions": ["e.g. Federal Reserve, SEC, DOJ"],
    "key_metrics": ["Key figures e.g. '$30.04B revenue', '50 bps cut'"]
  }
}`,
    jsonOutputSchema: `{
  "type": "object",
  "properties": {
    "entities": {
      "type": "object",
      "properties": {
        "companies": { "type": "array", "items": { "type": "string" } },
        "tickers": { "type": "array", "items": { "type": "string" } },
        "sectors": { "type": "array", "items": { "type": "string" } },
        "regulators_and_institutions": { "type": "array", "items": { "type": "string" } },
        "key_metrics": { "type": "array", "items": { "type": "string" } }
      },
      "required": ["companies", "tickers", "sectors", "regulators_and_institutions", "key_metrics"]
    }
  },
  "required": ["entities"]
}`,
    safeguards: [
      'Standardize ticker symbols to uppercase letters.',
      'Filter out non-financial proper nouns.'
    ]
  }
];

export const DEMO_VIDEO_SCRIPT_DATA = [
  {
    step: '1. Introduction (0:00 - 0:45)',
    title: 'Welcome & Project Objective',
    speech: `"Hello mentors and fellow engineers! My name is Parth Gurav, and today I am excited to present my capstone project: the Financial News Simplifier.\n\nFinancial news today is filled with dense jargon like 'hawkish pause', 'basis points', 'yield curve inversions', and 'gross margin compression'. For an ordinary citizen, student, or first-time investor, reading the Wall Street Journal or Bloomberg feels like reading an alien language. My project bridges that gap by using generative AI to ingest complex financial journalism and translate it into plain English, actionable takeaways, and clear real-world impacts."`
  },
  {
    step: '2. Problem Statement & Target Audience (0:45 - 1:30)',
    title: 'The Challenge & Who It Helps',
    speech: `"The problem is financial exclusion due to linguistic and technical barriers. Ordinary people make critical financial choices—mortgages, student loans, 401(k) allocations, credit cards—without understanding how macroeconomic news directly affects them.\n\nOur target users are everyday consumers, university students, and beginner retail investors who want to stay informed in under 60 seconds without wading through 2,000 words of Wall Street analyst speak."`
  },
  {
    step: '3. Architecture & Data Flow (1:30 - 2:30)',
    title: 'End-to-End System Design',
    speech: `"Let's look at the system architecture. The flow works as follows: First, our React client requests the latest financial headlines. The backend server queries financial news feeds and normalizes diverse schemas.\n\nWhen a user clicks 'Simplify', the request hits our caching layer. If the article has been processed before, we instantly return the cached JSON in milliseconds. If it's a new article, the server passes the text through our prompt engineering pipeline to the Google Gemini model. Gemini executes our anti-hallucination prompt, returning structured JSON with a TL;DR, Jargon Buster, and 'Why It Matters' breakdown, which is stored in our database and rendered on the frontend."`
  },
  {
    step: '4. Application Walkthrough & News Feed (2:30 - 3:30)',
    title: 'Live News Feed & Category Filtering',
    speech: `"Here is our live running application. As you can see, the homepage displays clean, card-based financial news categorized into Central Banks, Technology & AI, Bond Markets, and Crypto.\n\nNotice the search bar: if I type 'Federal Reserve' or 'interest rates', the feed filters in real time with debounced queries. Each card highlights the news source, time published, and an interactive 'Simplify This' action button."`
  },
  {
    step: '5. AI Summarization & Deep Dive (3:30 - 5:00)',
    title: 'The AI Simplification in Action',
    speech: `"Now, let's click 'Simplify' on this complex Federal Reserve rate cut article. In less than 2 seconds, our modal pops up with four key sections:\n\n1. TL;DR: A single sentence explaining that the Fed cut rates by 0.50% to make borrowing cheaper.\n2. Key Points: Three bullet points with the exact numbers preserved—4.75%–5.00% target rate, 2.2% inflation.\n3. The Jargon Buster: Terms like '50 Basis Points' and 'Quantitative Tightening' are translated into plain everyday analogies.\n4. 'Why It Matters': Broken down into three practical columns: what it means for your credit card or mortgage, what it means for your stock index funds, and what it means for the US economy."`
  },
  {
    step: '6. Fact vs. Speculation Guardrails (5:00 - 6:00)',
    title: 'Anti-Hallucination & Educational Safeguards',
    speech: `"One critical engineering principle of this capstone is responsible AI. Financial advice hallucinations can hurt people. Therefore, our system strictly bifurcates verified facts from analyst speculation. Under 'Verified Facts', we show only official Fed voting numbers. Under 'Market Interpretations', we label analyst predictions.\n\nEvery summary also carries a clear educational disclaimer: 'AI-Generated Analysis - For Educational Purposes Only'."`
  },
  {
    step: '7. Technical Implementation & Database (6:00 - 7:00)',
    title: 'Tech Stack & Schema Highlights',
    speech: `"Under the hood, we used TypeScript across both frontend and backend. On the frontend, React with Vite and Tailwind CSS provides high-speed responsive UI. On the backend, Express handles API routing and CORS security. We designed normalized database tables: Users, Articles, Summaries, Bookmarks, and Search History.\n\nOur AI pipeline utilizes the modern @google/genai TypeScript SDK with Gemini 2.5 Flash, which delivers sub-2-second generation times at negligible cost."`
  },
  {
    step: '8. GitHub Repository & Kanban Workflow (7:00 - 8:00)',
    title: 'Engineering Process & Agile Delivery',
    speech: `"Throughout this project, I maintained strict Git hygiene. We used feature branches following the git-flow convention: 'feature/news-ingestion', 'feature/gemini-prompts', and 'feature/caching-layer'. Never did any API keys or secrets enter version control; everything is managed through .env and .env.example.\n\nI tracked all 28 project tasks on our Kanban board across 8 distinct phases, moving every User Story from To Do, to In Progress, and finally to Review upon passing definition of done."`
  },
  {
    step: '9. Testing & Reliability (8:00 - 8:45)',
    title: 'Testing Edge Cases & Guardrails',
    speech: `"We authored unit tests for article normalization, schema validation tests for LLM outputs, and integration tests for caching. We specifically tested edge cases: what happens when an article is 10,000 words long? We truncate to the first 4,000 tokens. What if the news API is rate-limited? Our system seamlessly falls back to pre-cached articles or fallback RSS feeds so the user never sees a broken screen."`
  },
  {
    step: '10. Conclusion & Mentor Q&A (8:45 - 9:30)',
    title: 'Wrap-Up & Thank You',
    speech: `"In conclusion, the Financial News Simplifier successfully democratizes financial journalism. By turning complex Wall Street reports into accessible, everyday knowledge, we empower ordinary people to make confident financial decisions.\n\nThank you for your mentorship and time, and I look forward to your questions and feedback!"`
  }
];
