import React, { useState } from 'react';
import { DATABASE_TABLES_DATA, API_ENDPOINTS_DATA } from '../data/planData';
import { DatabaseTable, ApiEndpoint } from '../types';
import { Database, Key, Send, Copy, Check, Terminal, ExternalLink, Code2 } from 'lucide-react';

export const DatabaseApiExplorer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'db' | 'api'>('db');
  const [selectedTable, setSelectedTable] = useState<DatabaseTable>(DATABASE_TABLES_DATA[1]); // articles
  const [selectedEndpoint, setSelectedEndpoint] = useState<ApiEndpoint>(API_ENDPOINTS_DATA[2]); // summarize
  const [testResult, setTestResult] = useState<string | null>(null);
  const [isCalling, setIsCalling] = useState<boolean>(false);
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  const handleSimulateApiCall = () => {
    setIsCalling(true);
    setTestResult(null);
    setTimeout(() => {
      setIsCalling(false);
      setTestResult(selectedEndpoint.responseStructure);
    }, 450);
  };

  const copyCurl = () => {
    const curl = `curl -X ${selectedEndpoint.method} "https://your-domain.com${selectedEndpoint.endpoint}" \\
  -H "Content-Type: application/json" \\
  ${selectedEndpoint.requestParamsOrBody ? `-d '${selectedEndpoint.requestParamsOrBody.replace(/\n/g, '')}'` : ''}`;
    navigator.clipboard.writeText(curl);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Tab Switcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            Backend Engineering Specs
          </span>
          <h2 className="text-xl font-bold mt-1 text-white">Database Schema & REST API Explorer</h2>
          <p className="text-xs text-slate-400">
            Normalized relational database tables with foreign key constraints, plus production-ready REST API endpoints.
          </p>
        </div>

        <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setActiveTab('db')}
            className={`px-4 py-1.5 text-xs font-semibold rounded-md transition ${
              activeTab === 'db'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Database Schema ({DATABASE_TABLES_DATA.length} Tables)
          </button>
          <button
            onClick={() => setActiveTab('api')}
            className={`px-4 py-1.5 text-xs font-semibold rounded-md transition ${
              activeTab === 'api'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            REST API Endpoints ({API_ENDPOINTS_DATA.length} Routes)
          </button>
        </div>
      </div>

      {/* DATABASE TAB */}
      {activeTab === 'db' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Table List Sidebar */}
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Database size={14} className="text-blue-400" /> Relational Tables
            </div>
            {DATABASE_TABLES_DATA.map(tbl => (
              <button
                key={tbl.name}
                onClick={() => setSelectedTable(tbl)}
                className={`w-full text-left p-3 rounded-lg border transition ${
                  selectedTable.name === tbl.name
                    ? 'bg-blue-600/20 border-blue-500 text-white'
                    : 'bg-slate-950 border-slate-800/80 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-200">{tbl.name}</span>
                  <span className="text-[10px] text-slate-400">{tbl.fields.length} columns</span>
                </div>
                <div className="text-[11px] text-slate-400 truncate mt-1">
                  {tbl.description}
                </div>
              </button>
            ))}

            <div className="mt-4 p-3 bg-slate-950 border border-slate-800/80 rounded-lg text-[11px] text-slate-400 space-y-1">
              <div className="font-semibold text-slate-300">Entity Relationships:</div>
              <div>• <code>articles.id</code> 1-to-1 <code>summaries.article_id</code></div>
              <div>• <code>users.id</code> 1-to-many <code>bookmarks.user_id</code></div>
              <div>• <code>articles.id</code> 1-to-many <code>bookmarks.article_id</code></div>
              <div>• <code>users.id</code> 1-to-many <code>search_history.user_id</code></div>
            </div>
          </div>

          {/* Table Details */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <span className="text-[11px] font-mono text-blue-400 uppercase">TABLE SCHEMA</span>
                <h3 className="text-lg font-bold text-white font-mono">{selectedTable.name}</h3>
                <p className="text-xs text-slate-400">{selectedTable.description}</p>
              </div>
              <span className="px-2.5 py-1 rounded bg-slate-800 text-xs font-mono text-slate-300">
                PostgreSQL / SQLite
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 uppercase font-mono text-[10px]">
                    <th className="py-2.5 px-3">Field Name</th>
                    <th className="py-2.5 px-3">Data Type</th>
                    <th className="py-2.5 px-3">Keys / Constraints</th>
                    <th className="py-2.5 px-3">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {selectedTable.fields.map(f => (
                    <tr key={f.name} className="hover:bg-slate-950/40 transition">
                      <td className="py-2.5 px-3 font-semibold text-slate-200">
                        {f.name}
                      </td>
                      <td className="py-2.5 px-3 text-amber-400">
                        {f.type}
                      </td>
                      <td className="py-2.5 px-3">
                        {f.isPk && (
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                            <Key size={10} /> PK
                          </span>
                        )}
                        {f.isFk && (
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[10px] font-bold">
                            FK → {f.refTable}
                          </span>
                        )}
                        {!f.isPk && !f.isFk && (
                          <span className="text-slate-400 text-[10px]">
                            {f.nullable ? 'NULL' : 'NOT NULL'}
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 font-sans text-xs text-slate-300">
                        {f.description}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* API TAB */}
      {activeTab === 'api' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Endpoint List Sidebar */}
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Terminal size={14} className="text-blue-400" /> REST Endpoints
            </div>
            {API_ENDPOINTS_DATA.map(ep => (
              <button
                key={ep.endpoint + ep.method}
                onClick={() => { setSelectedEndpoint(ep); setTestResult(null); }}
                className={`w-full text-left p-3 rounded-lg border transition ${
                  selectedEndpoint.endpoint === ep.endpoint && selectedEndpoint.method === ep.method
                    ? 'bg-blue-600/20 border-blue-500 text-white'
                    : 'bg-slate-950 border-slate-800/80 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold font-mono ${
                    ep.method === 'GET' ? 'bg-blue-500/20 text-blue-400' :
                    ep.method === 'POST' ? 'bg-emerald-500/20 text-emerald-400' :
                    ep.method === 'DELETE' ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'
                  }`}>
                    {ep.method}
                  </span>
                  <span className="font-mono text-xs font-medium text-slate-200 truncate">{ep.endpoint}</span>
                </div>
                <div className="text-[11px] text-slate-400 truncate mt-1">
                  {ep.purpose}
                </div>
              </button>
            ))}
          </div>

          {/* Endpoint Inspector & Runner */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-xs font-bold font-mono ${
                    selectedEndpoint.method === 'GET' ? 'bg-blue-500/20 text-blue-400' :
                    selectedEndpoint.method === 'POST' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {selectedEndpoint.method}
                  </span>
                  <h3 className="text-base font-bold text-white font-mono">{selectedEndpoint.endpoint}</h3>
                </div>
                <p className="text-xs text-slate-400 mt-1">{selectedEndpoint.purpose}</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={copyCurl}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-xs rounded text-slate-300 border border-slate-700 flex items-center gap-1 transition"
                >
                  {copiedSnippet ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                  <span>{copiedSnippet ? 'Copied' : 'cURL'}</span>
                </button>
                <button
                  onClick={handleSimulateApiCall}
                  disabled={isCalling}
                  className="px-3.5 py-1 bg-blue-600 hover:bg-blue-500 text-xs font-semibold rounded text-white flex items-center gap-1.5 transition"
                >
                  <Send size={12} />
                  <span>{isCalling ? 'Sending...' : 'Send Test Request'}</span>
                </button>
              </div>
            </div>

            {/* Request Details */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-300 block">Parameters / Request Body:</span>
              <pre className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-[11px] text-amber-300 overflow-x-auto whitespace-pre-wrap">
                {selectedEndpoint.requestParamsOrBody || '(No request body required)'}
              </pre>
            </div>

            {/* Response Structure */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">
                  {testResult ? 'Live Simulation Response (200 OK):' : 'Expected Response Structure (JSON):'}
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">Status: 200 OK</span>
              </div>
              <pre className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 font-mono text-[11px] text-emerald-400 overflow-x-auto max-h-[300px]">
                {testResult || selectedEndpoint.responseStructure}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
