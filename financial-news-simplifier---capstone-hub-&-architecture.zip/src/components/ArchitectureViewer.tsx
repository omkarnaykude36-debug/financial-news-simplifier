import React, { useState } from 'react';
import { Copy, Check, Server, Database, Brain, Globe, Laptop, ArrowRight } from 'lucide-react';

export const ArchitectureViewer: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [activeComponent, setActiveComponent] = useState<string>('llm');

  const asciiDiagram = `+---------------------------------------------------------------------------------------------------------+
|                                    FINANCIAL NEWS SIMPLIFIER ARCHITECTURE                               |
+---------------------------------------------------------------------------------------------------------+

  [ END USER ]
       |
       | 1. HTTP / Web Browsing (Reads simplified news, searches topics, toggles bookmarks)
       v
+---------------------------------------------------------------------------------------------------------+
| FRONTEND CLIENT (React 19 + TypeScript + Vite + Tailwind CSS)                                           |
|  - News Feed Dashboard (category pills, debounced search bar)                                           |
|  - Article Reader with "Simplify This" CTA                                                              |
|  - AI Simplification Modal: TL;DR, 3 Takeaways, Jargon Buster tooltips, Why It Matters                  |
|  - Sentiment Gauge, Entities Radar, and Facts vs. Speculation Matrix                                    |
|  - Saved Bookmarks & Search History Drawer                                                              |
+---------------------------------------------------------------------------------------------------------+
       |                                                    ^
       | 2. REST API Requests (JSON over HTTPS)              | 8. Clean JSON payload (<100ms if cached)
       v                                                    |
+---------------------------------------------------------------------------------------------------------+
| BACKEND API SERVER (Node.js / Express or FastAPI)                                                       |
|  - Security & Middleware: Helmet, CORS whitelist, Rate Limiting (express-rate-limit)                     |
|  - Route Handlers: /api/news, /api/articles/:id, /api/summarize, /api/bookmarks, /api/search/history    |
|  - Request Validation: Zod schema validators (validates URLs, IDs, reading level)                       |
+---------------------------------------------------------------------------------------------------------+
       |                                                    ^
       | 3. Query external news or DB cache                 | 7. Return cached or freshly generated summary
       v                                                    |
  +--------------------------------+               +---------------------------------------------------+
  | EXTERNAL NEWS INGESTION LAYER  |               | CACHING & SUMMARY CONTROLLER                      |
  |  - NewsAPI / Finnhub / RSS     |               |  - Checks DB for existing article hash            |
  |  - Article HTML cleaning       |               |  - Cache HIT: returns stored summary immediately  |
  |  - Deduplication by URL hash   |               |  - Cache MISS: triggers AI Processing Pipeline    |
  +--------------------------------+               +---------------------------------------------------+
                                                            |
                                                            | 4. Forward cleaned text to LLM
                                                            v
                                                   +---------------------------------------------------+
                                                   | AI / LLM PROCESSING ENGINE                        |
                                                   |  - SDK: @google/genai TypeScript SDK              |
                                                   |  - Model: gemini-2.5-flash                        |
                                                   |  - System Prompt: Plain English (Grade 8)         |
                                                   |  - Guardrails: Exact number retention,            |
                                                   |    anti-hallucination, facts vs. opinion split    |
                                                   |  - Response Format: Structured Strict JSON Schema |
                                                   +---------------------------------------------------+
                                                            |
                                                            | 5. Validated JSON response
                                                            v
+---------------------------------------------------------------------------------------------------------+
| RELATIONAL DATABASE PERSISTENCE LAYER (PostgreSQL / SQLite via Drizzle or Prisma)                       |
|  - [articles] : id, title, source_name, source_url, url_hash, raw_content, published_at                 |
|  - [summaries]: id, article_id, tldr, key_points, why_it_matters, jargon_buster, entities, sentiment    |
|  - [users]    : id, email, display_name, preferred_reading_level, created_at                            |
|  - [bookmarks]: id, user_id, article_id, notes, created_at                                               |
|  - [search_history]: id, user_id, query_text, result_count, searched_at                                 |
+---------------------------------------------------------------------------------------------------------+`;

  const copyAscii = () => {
    navigator.clipboard.writeText(asciiDiagram);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const components = [
    {
      id: 'frontend',
      title: 'Frontend Client (SPA)',
      icon: Laptop,
      tech: 'React 19, Vite, Tailwind CSS, Lucide',
      responsibility: 'Renders the responsive user interface, manages client state, triggers debounced search queries, formats jargon tooltips, and persists bookmark toggles.',
      security: 'Zero API keys stored in client bundle. All calls route through backend proxy.',
      failureStrategy: 'Offline resilience fallback, skeleton placeholders, and error boundaries.'
    },
    {
      id: 'backend',
      title: 'Backend API Server',
      icon: Server,
      tech: 'Node.js, Express, TypeScript, Zod',
      responsibility: 'Exposes clean RESTful endpoints, enforces rate limits, validates incoming request bodies, coordinates external news fetching, and manages DB transactions.',
      security: 'CORS whitelist, helmet headers, input sanitization against XSS and SQL injection.',
      failureStrategy: 'Global error handling middleware returning standardized { success: false, error: string } JSON.'
    },
    {
      id: 'news',
      title: 'News Ingestion Layer',
      icon: Globe,
      tech: 'NewsAPI / Finnhub API / RSS Feeds',
      responsibility: 'Fetches recent economic and financial headlines, strips boilerplate HTML markup, and deduplicates news items using SHA-256 URL hashing.',
      security: 'News API keys stored exclusively in backend .env, never exposed to browser.',
      failureStrategy: 'Secondary fallback to financial RSS feeds (Reuters/Yahoo) when API quotas are exceeded.'
    },
    {
      id: 'llm',
      title: 'AI / LLM Processing Engine',
      icon: Brain,
      tech: 'Google GenAI SDK (@google/genai), gemini-2.5-flash',
      responsibility: 'Converts 2,000-word financial journalism into plain-English summaries, extracts jargon with real-world analogies, scores market sentiment, and maps "Why It Matters".',
      security: 'Strict system prompts prevent prompt injection and disallow financial advice generation.',
      failureStrategy: 'Strict JSON schema parsing with fallback regex extractor and exponential backoff retry.'
    },
    {
      id: 'database',
      title: 'Database & Cache Layer',
      icon: Database,
      tech: 'PostgreSQL / SQLite, Drizzle ORM',
      responsibility: 'Stores articles, user accounts, bookmarks, search queries, and pre-computed summaries to ensure sub-100ms response times on repeated reads.',
      security: 'Parameterized queries eliminate SQL injection; unique constraints on URL hash prevent duplicate ingestion.',
      failureStrategy: 'Connection pooling with automated reconnection and transactional rollbacks.'
    }
  ];

  const currentComp = components.find(c => c.id === activeComponent) || components[0];

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-white">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              System Architecture & Data Flow
            </span>
            <h2 className="text-xl font-bold mt-1 text-white">End-to-End Pipeline Design</h2>
            <p className="text-sm text-slate-400">
              User → Frontend → Backend API → News API → Normalization → Gemini LLM → Relational Database → Frontend
            </p>
          </div>

          <button
            onClick={copyAscii}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-slate-200 border border-slate-700 transition"
          >
            {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
            <span>{copied ? 'Copied ASCII Diagram' : 'Copy ASCII Diagram'}</span>
          </button>
        </div>
      </div>

      {/* Visual Component Selector */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {components.map(comp => {
          const Icon = comp.icon;
          const isSelected = comp.id === activeComponent;
          return (
            <button
              key={comp.id}
              onClick={() => setActiveComponent(comp.id)}
              className={`p-3.5 rounded-xl border text-left transition flex flex-col justify-between ${
                isSelected
                  ? 'bg-blue-600/20 border-blue-500 text-white shadow-lg'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between w-full mb-2">
                <Icon size={18} className={isSelected ? 'text-blue-400' : 'text-slate-400'} />
                {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-blue-400" />}
              </div>
              <div>
                <div className="text-xs font-bold text-slate-100">{comp.title}</div>
                <div className="text-[10px] text-slate-400 truncate mt-0.5">{comp.tech}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Component Deep Dive */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-white space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
          <currentComp.icon size={20} className="text-blue-400" />
          <div>
            <h3 className="text-base font-bold text-white">{currentComp.title}</h3>
            <span className="text-xs text-blue-400 font-mono">{currentComp.tech}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-1">
            <span className="font-semibold text-slate-300 block">Core Responsibility:</span>
            <p className="text-slate-400 leading-relaxed">{currentComp.responsibility}</p>
          </div>
          <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-1">
            <span className="font-semibold text-slate-300 block">Security & Isolation:</span>
            <p className="text-slate-400 leading-relaxed">{currentComp.security}</p>
          </div>
          <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-1">
            <span className="font-semibold text-slate-300 block">Failure Resilience Strategy:</span>
            <p className="text-slate-400 leading-relaxed">{currentComp.failureStrategy}</p>
          </div>
        </div>
      </div>

      {/* ASCII Architecture Code Block */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 overflow-x-auto">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs text-slate-400">
          <span className="font-mono text-[11px]">system_architecture_diagram.txt</span>
          <span className="text-[10px]">Strict Modular Clean Architecture</span>
        </div>
        <pre className="font-mono text-[11px] text-emerald-400 leading-tight select-all">
          {asciiDiagram}
        </pre>
      </div>
    </div>
  );
};
