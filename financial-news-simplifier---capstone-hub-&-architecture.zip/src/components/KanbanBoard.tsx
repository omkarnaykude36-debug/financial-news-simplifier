import React, { useState } from 'react';
import { KanbanTask, KanbanStatus } from '../types';
import { CheckCircle2, Clock, AlertCircle, Filter, ArrowRight, ArrowLeft, CheckSquare, Layers } from 'lucide-react';

interface KanbanBoardProps {
  tasks: KanbanTask[];
  onUpdateStatus: (taskId: string, newStatus: KanbanStatus) => void;
}

export const KanbanBoard: React.FC<KanbanBoardProps> = ({ tasks, onUpdateStatus }) => {
  const [selectedPhase, setSelectedPhase] = useState<string>('All');
  const [selectedEpic, setSelectedEpic] = useState<string>('All');
  const [selectedTask, setSelectedTask] = useState<KanbanTask | null>(null);

  const phases = ['All', 'Phase 1: Setup', 'Phase 2: News Integration', 'Phase 3: AI/LLM', 'Phase 4: Backend', 'Phase 5: Frontend', 'Phase 6: Testing', 'Phase 7: Deployment', 'Phase 8: Documentation & Demo'];
  const epics = ['All', 'Project Setup', 'News Data Integration', 'AI/LLM Processing', 'Backend Development', 'Database', 'Frontend Development', 'Testing', 'Deployment', 'Documentation'];

  const filteredTasks = tasks.filter(task => {
    const phaseMatch = selectedPhase === 'All' || task.phase === selectedPhase;
    const epicMatch = selectedEpic === 'All' || task.epic === selectedEpic;
    return phaseMatch && epicMatch;
  });

  const todoTasks = filteredTasks.filter(t => t.status === 'To Do');
  const inProgressTasks = filteredTasks.filter(t => t.status === 'In Progress');
  const reviewTasks = filteredTasks.filter(t => t.status === 'Review');

  const totalTasks = tasks.length;
  const completedReview = tasks.filter(t => t.status === 'Review').length;
  const inProgressCount = tasks.filter(t => t.status === 'In Progress').length;
  const todoCount = tasks.filter(t => t.status === 'To Do').length;
  const progressPercent = Math.round((completedReview / totalTasks) * 100);

  return (
    <div className="space-y-6">
      {/* Header & Metrics */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-white shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Agile Kanban Workflow
              </span>
              <span className="text-xs text-slate-400">Strict Rule: To Do → In Progress → Review</span>
            </div>
            <h2 className="text-xl font-bold mt-1 text-white">Capstone Project Sprint Board</h2>
            <p className="text-sm text-slate-400">
              Track and transition all 28 project deliverables across 8 distinct capstone phases.
            </p>
          </div>

          <div className="flex items-center gap-4 bg-slate-950 p-3 rounded-lg border border-slate-800">
            <div className="text-center px-2">
              <div className="text-xs text-slate-400">Total Tasks</div>
              <div className="text-lg font-bold text-slate-200">{totalTasks}</div>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div className="text-center px-2">
              <div className="text-xs text-amber-400">To Do</div>
              <div className="text-lg font-bold text-amber-400">{todoCount}</div>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div className="text-center px-2">
              <div className="text-xs text-blue-400">In Progress</div>
              <div className="text-lg font-bold text-blue-400">{inProgressCount}</div>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div className="text-center px-2">
              <div className="text-xs text-emerald-400">Review (Done)</div>
              <div className="text-lg font-bold text-emerald-400">{completedReview}</div>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-4">
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span>Overall Sprint Completion</span>
            <span className="font-semibold text-emerald-400">{progressPercent}% Ready for Review</span>
          </div>
          <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-emerald-400 transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Filters */}
        <div className="mt-5 flex flex-wrap items-center gap-3 pt-2">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Filter size={14} /> Filter by:
          </div>
          
          <select
            value={selectedPhase}
            onChange={(e) => setSelectedPhase(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-xs rounded-lg px-3 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
          >
            {phases.map(p => (
              <option key={p} value={p}>{p === 'All' ? 'All Phases (1-8)' : p}</option>
            ))}
          </select>

          <select
            value={selectedEpic}
            onChange={(e) => setSelectedEpic(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-xs rounded-lg px-3 py-1.5 text-slate-200 focus:outline-none focus:border-blue-500"
          >
            {epics.map(ep => (
              <option key={ep} value={ep}>{ep === 'All' ? 'All Epics' : ep}</option>
            ))}
          </select>

          {(selectedPhase !== 'All' || selectedEpic !== 'All') && (
            <button
              onClick={() => { setSelectedPhase('All'); setSelectedEpic('All'); }}
              className="text-xs text-blue-400 hover:underline ml-auto"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Kanban Columns */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Column 1: To Do */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <h3 className="font-semibold text-sm text-slate-200">To Do</h3>
            </div>
            <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md">
              {todoTasks.length}
            </span>
          </div>

          <div className="space-y-3 flex-1 overflow-y-auto max-h-[700px] pr-1">
            {todoTasks.length === 0 ? (
              <div className="text-center py-10 text-xs text-slate-500 border border-dashed border-slate-800 rounded-lg">
                No tasks in To Do for this filter.
              </div>
            ) : (
              todoTasks.map(task => (
                <div
                  key={task.id}
                  onClick={() => setSelectedTask(task)}
                  className="bg-slate-950 hover:border-slate-700 border border-slate-800/80 rounded-lg p-3.5 cursor-pointer transition shadow-sm hover:shadow-md group relative"
                >
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-mono text-[11px] font-semibold text-amber-400/90">{task.id}</span>
                    <span className="text-[10px] px-2 py-0.5 bg-slate-800/80 rounded text-slate-400">{task.epic}</span>
                  </div>
                  <h4 className="text-xs font-medium text-slate-200 leading-snug group-hover:text-blue-400 transition">
                    {task.task}
                  </h4>
                  <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/60 pt-2">
                    <span className="truncate max-w-[170px]" title={task.phase}>{task.phase}</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateStatus(task.id, 'In Progress');
                      }}
                      className="inline-flex items-center gap-1 text-[11px] text-blue-400 hover:text-blue-300 font-medium bg-blue-950/60 border border-blue-800/50 px-2 py-0.5 rounded transition"
                      title="Move to In Progress"
                    >
                      Start <ArrowRight size={11} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Column 2: In Progress */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-blue-400 animate-pulse" />
              <h3 className="font-semibold text-sm text-slate-200">In Progress</h3>
            </div>
            <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md">
              {inProgressTasks.length}
            </span>
          </div>

          <div className="space-y-3 flex-1 overflow-y-auto max-h-[700px] pr-1">
            {inProgressTasks.length === 0 ? (
              <div className="text-center py-10 text-xs text-slate-500 border border-dashed border-slate-800 rounded-lg">
                No active tasks. Click &quot;Start&quot; on a To Do card.
              </div>
            ) : (
              inProgressTasks.map(task => (
                <div
                  key={task.id}
                  onClick={() => setSelectedTask(task)}
                  className="bg-slate-950 border-blue-900/40 hover:border-blue-700/60 border rounded-lg p-3.5 cursor-pointer transition shadow-sm hover:shadow-md group relative"
                >
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-mono text-[11px] font-semibold text-blue-400">{task.id}</span>
                    <span className="text-[10px] px-2 py-0.5 bg-blue-950/60 border border-blue-800/40 rounded text-blue-300">{task.epic}</span>
                  </div>
                  <h4 className="text-xs font-medium text-slate-100 leading-snug group-hover:text-blue-300 transition">
                    {task.task}
                  </h4>
                  <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/60 pt-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateStatus(task.id, 'To Do');
                      }}
                      className="inline-flex items-center gap-1 text-[11px] text-slate-400 hover:text-slate-200 transition"
                      title="Move back to To Do"
                    >
                      <ArrowLeft size={11} /> Back
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateStatus(task.id, 'Review');
                      }}
                      className="inline-flex items-center gap-1 text-[11px] text-emerald-400 hover:text-emerald-300 font-medium bg-emerald-950/60 border border-emerald-800/50 px-2 py-0.5 rounded transition"
                      title="Move to Review"
                    >
                      To Review <CheckSquare size={11} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Column 3: Review */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <h3 className="font-semibold text-sm text-slate-200">Review (Definition of Done)</h3>
            </div>
            <span className="text-xs font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md">
              {reviewTasks.length}
            </span>
          </div>

          <div className="space-y-3 flex-1 overflow-y-auto max-h-[700px] pr-1">
            {reviewTasks.length === 0 ? (
              <div className="text-center py-10 text-xs text-slate-500 border border-dashed border-slate-800 rounded-lg">
                No tasks ready for Review yet.
              </div>
            ) : (
              reviewTasks.map(task => (
                <div
                  key={task.id}
                  onClick={() => setSelectedTask(task)}
                  className="bg-slate-950 border-emerald-900/30 hover:border-emerald-700/50 border rounded-lg p-3.5 cursor-pointer transition shadow-sm hover:shadow-md group relative"
                >
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-mono text-[11px] font-semibold text-emerald-400">{task.id}</span>
                    <span className="text-[10px] px-2 py-0.5 bg-emerald-950/60 border border-emerald-800/30 rounded text-emerald-300">{task.epic}</span>
                  </div>
                  <h4 className="text-xs font-medium text-slate-200 leading-snug group-hover:text-emerald-300 transition">
                    {task.task}
                  </h4>
                  <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/60 pt-2">
                    <span className="text-emerald-400/90 text-[10px] flex items-center gap-1 font-medium">
                      <CheckCircle2 size={11} /> Ready for Mentor
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateStatus(task.id, 'In Progress');
                      }}
                      className="inline-flex items-center gap-1 text-[10px] text-slate-400 hover:text-slate-200 transition"
                      title="Move back to In Progress"
                    >
                      <ArrowLeft size={10} /> Reopen
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Task Detail Modal */}
      {selectedTask && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-xl w-full p-6 text-white space-y-4 shadow-2xl relative">
            <button
              onClick={() => setSelectedTask(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg font-bold"
            >
              ✕
            </button>

            <div className="flex items-center gap-2">
              <span className="font-mono text-xs px-2.5 py-1 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30 font-bold">
                {selectedTask.id}
              </span>
              <span className="text-xs px-2 py-1 rounded bg-slate-800 text-slate-300">
                {selectedTask.epic}
              </span>
              <span className="text-xs text-slate-400">{selectedTask.phase}</span>
            </div>

            <h3 className="text-lg font-bold text-white">{selectedTask.task}</h3>

            <p className="text-sm text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-lg border border-slate-800">
              {selectedTask.description || 'Deliverable implementation task.'}
            </p>

            <div className="space-y-2 text-xs">
              <div className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Layers size={14} className="text-blue-400" /> Deliverable:
              </div>
              <p className="bg-slate-950/60 p-2.5 rounded text-slate-300 border border-slate-800/80 font-mono text-[11px]">
                {selectedTask.deliverable}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <span className="text-slate-400 block mb-1">Dependencies:</span>
                <span className="font-mono text-slate-200">{selectedTask.dependency}</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <span className="text-slate-400 block mb-1">Current Kanban Status:</span>
                <span className={`font-semibold ${
                  selectedTask.status === 'Review' ? 'text-emerald-400' :
                  selectedTask.status === 'In Progress' ? 'text-blue-400' : 'text-amber-400'
                }`}>
                  {selectedTask.status}
                </span>
              </div>
            </div>

            {selectedTask.acceptanceCriteria && (
              <div className="space-y-1.5 text-xs">
                <div className="font-semibold text-slate-300 flex items-center gap-1.5">
                  <CheckSquare size={13} className="text-amber-400" /> Acceptance Criteria:
                </div>
                <ul className="space-y-1 pl-1">
                  {selectedTask.acceptanceCriteria.map((ac, idx) => (
                    <li key={idx} className="text-slate-400 flex items-start gap-2">
                      <span className="text-amber-400">•</span> {ac}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {selectedTask.definitionOfDone && (
              <div className="space-y-1.5 text-xs">
                <div className="font-semibold text-slate-300 flex items-center gap-1.5">
                  <CheckCircle2 size={13} className="text-emerald-400" /> Definition of Done:
                </div>
                <ul className="space-y-1 pl-1">
                  {selectedTask.definitionOfDone.map((dod, idx) => (
                    <li key={idx} className="text-slate-400 flex items-start gap-2">
                      <span className="text-emerald-400">✓</span> {dod}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Quick Status Changers */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-800">
              <div className="text-xs text-slate-400">Move status:</div>
              <div className="flex gap-2">
                <button
                  onClick={() => { onUpdateStatus(selectedTask.id, 'To Do'); setSelectedTask({ ...selectedTask, status: 'To Do' }); }}
                  className={`px-3 py-1 text-xs rounded font-medium border ${selectedTask.status === 'To Do' ? 'bg-amber-500/20 text-amber-300 border-amber-500/50' : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'}`}
                >
                  To Do
                </button>
                <button
                  onClick={() => { onUpdateStatus(selectedTask.id, 'In Progress'); setSelectedTask({ ...selectedTask, status: 'In Progress' }); }}
                  className={`px-3 py-1 text-xs rounded font-medium border ${selectedTask.status === 'In Progress' ? 'bg-blue-500/20 text-blue-300 border-blue-500/50' : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'}`}
                >
                  In Progress
                </button>
                <button
                  onClick={() => { onUpdateStatus(selectedTask.id, 'Review'); setSelectedTask({ ...selectedTask, status: 'Review' }); }}
                  className={`px-3 py-1 text-xs rounded font-medium border ${selectedTask.status === 'Review' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50' : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'}`}
                >
                  Review
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
