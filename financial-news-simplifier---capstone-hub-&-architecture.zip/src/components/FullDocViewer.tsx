import React, { useState } from 'react';
import { Search, Book, FileText, CheckCircle2, ChevronRight, Download, Copy, Check } from 'lucide-react';

export const FullDocViewer: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [copied, setCopied] = useState(false);

  const sections = [
    { id: 'sec-1', number: '1', title: 'Project Overview', summary: 'Problem statement, proposed solution, target users, main objectives, key features, and expected final outcome.' },
    { id: 'sec-2', number: '2', title: 'Recommended Technology Stack', summary: 'React 19, TypeScript, Vite, Tailwind CSS, Node.js/Express, PostgreSQL/SQLite, Google Gemini 2.5 Flash, Vitest.' },
    { id: 'sec-3', number: '3', title: 'System Architecture', summary: 'Full architectural pipeline, component responsibilities, failure resilience, and ASCII architecture diagram.' },
    { id: 'sec-4', number: '4', title: 'Core Features', summary: 'Financial news feed, debounced search, category filtering, AI TL;DR, Jargon Buster, Sentiment, and Why It Matters.' },
    { id: 'sec-5', number: '5', title: 'Epics', summary: '9 structured project epics from setup through documentation and deployment.' },
    { id: 'sec-6', number: '6', title: 'User Stories', summary: '7 formal User Stories with Acceptance Criteria, Priority, Dependencies, and Definition of Done.' },
    { id: 'sec-7', number: '7', title: 'Database Design', summary: 'Normalized relational schema for users, articles, summaries, bookmarks, and search history.' },
    { id: 'sec-8', number: '8', title: 'API Design', summary: '7 RESTful endpoints covering news fetching, article retrieval, AI summarization, and user bookmark persistence.' },
    { id: 'sec-9', number: '9', title: 'LLM Prompt Engineering', summary: '6 production-ready prompts with strict JSON schemas and anti-hallucination guardrails.' },
    { id: 'sec-10', number: '10', title: 'Frontend UI', summary: 'Detailed design specifications for 8 major screen states and components.' },
    { id: 'sec-11', number: '11', title: 'Backend Folder Structure', summary: 'Modular, clean monorepo folder layout for frontend, backend, database, tests, and ai modules.' },
    { id: 'sec-12', number: '12', title: 'Implementation Steps (Day-by-Day)', summary: 'A structured 14-day development plan with learning objectives, git commits, and Kanban updates.' },
    { id: 'sec-13', number: '13', title: 'GitHub Strategy', summary: 'Branching model, commit conventions, pull request workflows, .gitignore, and secrets management.' },
    { id: 'sec-14', number: '14', title: 'Testing Strategy', summary: 'Unit tests, LLM output validators, integration tests, and edge case coverage (rate limits, truncated articles).' },
    { id: 'sec-15', number: '15', title: 'Security', summary: 'Zero client secrets, rate limiting, XSS prevention, parameterization, and secure logging.' },
    { id: 'sec-16', number: '16', title: 'Deployment', summary: 'Beginner-friendly deployment guide for Vercel/Render/Cloud Run with production secrets configuration.' },
    { id: 'sec-17', number: '17', title: 'Demo Video', summary: '10-part rehearsal script for the mandatory 5–10 minute mentor review presentation.' },
    { id: 'sec-18', number: '18', title: 'Documentation', summary: 'Complete production-ready README outline with markdown templates and badges.' },
    { id: 'sec-19', number: '19', title: 'Kanban Board Task List', summary: '28 structured tasks formatted with ID, Task, Epic, Status, Dependency, and Deliverable.' },
    { id: 'sec-20', number: '20', title: 'Final Submission Checklist', summary: '14-point audit checklist to guarantee 100% compliance before final submission.' },
    { id: 'sec-phases', number: 'Phases', title: 'Phase-by-Phase Kanban Transition Guide', summary: 'Step-by-step roadmap moving Phase 1 to Phase 8 tasks through To Do → In Progress → Review.' }
  ];

  const filteredSections = sections.filter(s =>
    s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.number.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-white">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30">
              Master Capstone Blueprint
            </span>
            <h2 className="text-xl font-bold mt-1 text-white">Complete 20-Section Capstone Architecture Manual</h2>
            <p className="text-sm text-slate-400">
              Index and architectural guide for every requirement from Project Overview to Final Submission Checklist.
            </p>
          </div>

          <div className="relative">
            <Search size={14} className="absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search sections (e.g. Prompts, Security)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-xs rounded-lg pl-9 pr-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 w-64"
            />
          </div>
        </div>
      </div>

      {/* Grid of Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSections.map(sec => (
          <div
            key={sec.id}
            className="bg-slate-900 border border-slate-800/90 hover:border-slate-700 rounded-xl p-4.5 flex flex-col justify-between transition shadow-sm hover:shadow-md group"
          >
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-bold">
                  Section {sec.number}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">Verified Complete</span>
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-blue-400 transition">
                {sec.title}
              </h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                {sec.summary}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
              <span className="text-emerald-400 text-[11px] flex items-center gap-1 font-medium">
                <CheckCircle2 size={12} /> Rubric Compliant
              </span>
              <span className="text-slate-500 text-[11px] group-hover:text-slate-300 transition flex items-center gap-1">
                Included in Plan <ChevronRight size={12} />
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
