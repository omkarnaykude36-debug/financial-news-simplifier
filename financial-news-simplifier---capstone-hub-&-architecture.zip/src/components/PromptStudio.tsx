import React, { useState } from 'react';
import { PROMPTS_DATA } from '../data/planData';
import { PromptTemplate } from '../types';
import { Brain, Copy, Check, ShieldCheck, FileCode, CheckCircle2 } from 'lucide-react';

export const PromptStudio: React.FC = () => {
  const [selectedPrompt, setSelectedPrompt] = useState<PromptTemplate>(PROMPTS_DATA[0]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyPrompt = (prompt: PromptTemplate) => {
    const fullPrompt = `=== SYSTEM PROMPT ===\n${prompt.systemPrompt}\n\n=== USER PROMPT TEMPLATE ===\n${prompt.userPromptTemplate}\n\n=== JSON SCHEMA ===\n${prompt.jsonOutputSchema}`;
    navigator.clipboard.writeText(fullPrompt);
    setCopiedId(prompt.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-white">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30">
              Prompt Engineering Suite
            </span>
            <h2 className="text-xl font-bold mt-1 text-white">Production LLM Prompts & Anti-Hallucination Guardrails</h2>
            <p className="text-sm text-slate-400">
              6 production-ready prompts designed for Google Gemini 2.5 Flash, structured JSON schemas, and anti-hallucination guardrails.
            </p>
          </div>

          <button
            onClick={() => copyPrompt(selectedPrompt)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-xs font-semibold rounded-lg text-white transition self-start md:self-auto"
          >
            {copiedId === selectedPrompt.id ? <Check size={14} /> : <Copy size={14} />}
            <span>{copiedId === selectedPrompt.id ? 'Copied Prompt Suite' : 'Copy Active Prompt'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Sidebar */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Brain size={14} className="text-blue-400" /> Prompt Templates
          </div>
          {PROMPTS_DATA.map(p => (
            <button
              key={p.id}
              onClick={() => setSelectedPrompt(p)}
              className={`w-full text-left p-3 rounded-lg border transition ${
                selectedPrompt.id === p.id
                  ? 'bg-blue-600/20 border-blue-500 text-white'
                  : 'bg-slate-950 border-slate-800/80 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="text-xs font-bold text-slate-200">{p.title}</div>
              <div className="text-[11px] text-slate-400 line-clamp-2 mt-1">
                {p.purpose}
              </div>
            </button>
          ))}

          <div className="mt-4 p-3 bg-slate-950 border border-slate-800/80 rounded-lg text-[11px] text-slate-400 space-y-1.5">
            <div className="font-semibold text-slate-300 flex items-center gap-1">
              <ShieldCheck size={13} className="text-emerald-400" /> Zero-Hallucination Rules:
            </div>
            <p>1. Never extrapolate beyond provided text.</p>
            <p>2. Strict JSON schema output ensures parsability.</p>
            <p>3. Explicitly separates facts from market opinion.</p>
          </div>
        </div>

        {/* Right Details */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5 text-white">
          <div className="pb-3 border-b border-slate-800">
            <h3 className="text-base font-bold text-white">{selectedPrompt.title}</h3>
            <p className="text-xs text-slate-300 mt-1">{selectedPrompt.purpose}</p>
          </div>

          {/* System Prompt */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-blue-400 uppercase font-mono text-[11px]">System Prompt</span>
              <span className="text-slate-400 text-[10px]">Defines persona, constraints, and readability grade</span>
            </div>
            <pre className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 font-mono text-[11px] text-slate-300 whitespace-pre-wrap leading-relaxed">
              {selectedPrompt.systemPrompt}
            </pre>
          </div>

          {/* User Prompt Template */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-amber-400 uppercase font-mono text-[11px]">User Prompt Template</span>
              <span className="text-slate-400 text-[10px]">Variables: {'{{title}}'}, {'{{source}}'}, {'{{article_text}}'}</span>
            </div>
            <pre className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 font-mono text-[11px] text-amber-300 whitespace-pre-wrap leading-relaxed">
              {selectedPrompt.userPromptTemplate}
            </pre>
          </div>

          {/* JSON Schema */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-emerald-400 uppercase font-mono text-[11px]">Strict JSON Schema Contract</span>
              <span className="text-slate-400 text-[10px]">Guarantees machine-readable responses</span>
            </div>
            <pre className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 font-mono text-[11px] text-emerald-400 whitespace-pre-wrap leading-relaxed">
              {selectedPrompt.jsonOutputSchema}
            </pre>
          </div>

          {/* Hallucination Safeguards */}
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 space-y-2">
            <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
              <ShieldCheck size={14} className="text-emerald-400" /> Active Safeguards & Validation Checks
            </span>
            <ul className="space-y-1 text-xs text-slate-400">
              {selectedPrompt.safeguards.map((sg, i) => (
                <li key={i} className="flex items-start gap-2">
                  <CheckCircle2 size={12} className="text-emerald-400 shrink-0 mt-0.5" />
                  <span>{sg}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
