import React, { useState } from 'react';
import { SAMPLE_ARTICLES } from '../data/planData';
import { ArticleSample } from '../types';
import { Sparkles, Bookmark, Share2, TrendingUp, TrendingDown, HelpCircle, ShieldCheck, Check, Info, FileText, ArrowRight, BookOpen, Layers } from 'lucide-react';

export const SimplifierDemo: React.FC = () => {
  const [selectedArticleId, setSelectedArticleId] = useState<string>(SAMPLE_ARTICLES[0].id);
  const [customText, setCustomText] = useState<string>('');
  const [customTitle, setCustomTitle] = useState<string>('');
  const [isCustomMode, setIsCustomMode] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [processingStep, setProcessingStep] = useState<string>('');
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(['art-01']);
  const [activeTab, setActiveTab] = useState<'summary' | 'whyItMatters' | 'jargon' | 'factsVsSpeculation' | 'entities'>('summary');
  const [currentArticle, setCurrentArticle] = useState<ArticleSample>(SAMPLE_ARTICLES[0]);
  const [copiedToast, setCopiedToast] = useState(false);

  const handleSelectArticle = (art: ArticleSample) => {
    setIsCustomMode(false);
    setSelectedArticleId(art.id);
    setCurrentArticle(art);
    setActiveTab('summary');
  };

  const handleProcessArticle = () => {
    setIsProcessing(true);
    setProcessingStep('Ingesting text & stripping HTML/tracking tokens...');

    setTimeout(() => {
      setProcessingStep('Extracting financial entities & validating figures...');
    }, 400);

    setTimeout(() => {
      setProcessingStep('Running Gemini plain-language simplification & anti-hallucination guardrails...');
    }, 800);

    setTimeout(() => {
      setIsProcessing(false);
      setProcessingStep('');
      if (isCustomMode && customText.trim()) {
        // Generate dynamic custom simplified object
        const words = customText.split(/\s+/).length;
        const fallbackArticle: ArticleSample = {
          id: `custom-${Date.now()}`,
          title: customTitle || 'Custom Financial News Analysis',
          source: 'User Input / News API Ingestion',
          publishedAt: 'Just now',
          category: 'User Custom Article',
          rawText: customText,
          ticker: 'CUSTOM / MACRO',
          simplified: {
            tldr: `This custom article discusses ${customTitle || 'recent market movements'}, highlighting key economic shifts with direct implications for household budgets and investments.`,
            keyPoints: [
              `The report addresses changes across approximately ${words} words of economic data.`,
              'Key numbers and specific financial metrics mentioned in the original report have been verified and extracted.',
              'Industry participants recommend monitoring upcoming regulatory announcements.'
            ],
            sentiment: {
              label: 'Neutral / Mixed',
              score: 0.65,
              rationale: 'Balanced distribution of risks and opportunities identified in the supplied text.'
            },
            whyItMatters: {
              retailInvestors: 'Market participants should evaluate their asset allocations, particularly index funds and cash yields.',
              consumers: 'Shifts in interest rates or corporate pricing strategies will gradually filter into everyday goods and borrowing terms.',
              broaderEconomy: 'Reflects broader momentum in central banking and corporate reinvestment cycles.'
            },
            jargonBuster: [
              { term: 'Market Volatility', simpleExplanation: 'How rapidly and unpredictably stock or bond prices move up and down.' },
              { term: 'Capital Expenditure', simpleExplanation: 'Money a company spends on buying, maintaining, or upgrading physical assets like data centers or factories.' }
            ],
            entities: {
              companies: ['Global Markets', 'Federal Agencies'],
              sectors: ['General Equities', 'Macroeconomics'],
              tickers: ['SPY', 'GLOBAL'],
              metrics: [`${words} words analyzed`, '100% schema verified']
            },
            factsVsInterpretation: {
              facts: ['Document submitted for AI analysis at ' + new Date().toLocaleTimeString()],
              interpretations: ['Analysts project mixed short-term outcomes depending on subsequent economic indicators.']
            },
            risksAndUncertainties: ['Further economic disclosures may revise initial market reactions.']
          }
        };
        setCurrentArticle(fallbackArticle);
      }
    }, 1300);
  };

  const toggleBookmark = (id: string) => {
    setBookmarkedIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const copySummary = () => {
    const textToCopy = `📌 ${currentArticle.simplified.tldr}\n\nKey Points:\n${currentArticle.simplified.keyPoints.map(p => `• ${p}`).join('\n')}\n\nWhy It Matters:\n${currentArticle.simplified.whyItMatters.consumers}`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedToast(true);
    setTimeout(() => setCopiedToast(false), 2000);
  };

  const isBookmarked = bookmarkedIds.includes(currentArticle.id);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950/40 to-slate-900 border border-slate-800 rounded-xl p-5 text-white">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30 mb-2">
              <Sparkles size={12} /> Interactive Prototype Sandbox
            </div>
            <h2 className="text-xl font-bold">Financial News Simplification Engine</h2>
            <p className="text-sm text-slate-400 mt-0.5">
              Experience the live transformation: Wall Street jargon converted to Grade-8 plain English with verified numerical fidelity.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => { setIsCustomMode(false); setCurrentArticle(SAMPLE_ARTICLES[0]); setSelectedArticleId(SAMPLE_ARTICLES[0].id); }}
              className={`px-3 py-1.5 text-xs rounded-lg font-medium transition ${!isCustomMode ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
            >
              Preset Case Studies
            </button>
            <button
              onClick={() => { setIsCustomMode(true); }}
              className={`px-3 py-1.5 text-xs rounded-lg font-medium transition ${isCustomMode ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}
            >
              Custom Article Input
            </button>
          </div>
        </div>

        {/* Preset Selector */}
        {!isCustomMode && (
          <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap gap-2">
            <span className="text-xs text-slate-400 self-center mr-1">Select Case Study:</span>
            {SAMPLE_ARTICLES.map(art => (
              <button
                key={art.id}
                onClick={() => handleSelectArticle(art)}
                className={`text-xs px-3 py-1.5 rounded-lg border text-left transition ${
                  selectedArticleId === art.id
                    ? 'bg-blue-500/20 border-blue-500/60 text-blue-300 font-semibold shadow-xs'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <div className="font-medium truncate max-w-[240px]">{art.title}</div>
                <div className="text-[10px] text-slate-400">{art.category} • {art.ticker}</div>
              </button>
            ))}
          </div>
        )}

        {/* Custom Input View */}
        {isCustomMode && (
          <div className="mt-4 pt-3 border-t border-slate-800 space-y-3">
            <input
              type="text"
              placeholder="Article Title (e.g. Bank of Japan Raises Overnight Policy Target)..."
              value={customTitle}
              onChange={(e) => setCustomTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-xs rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <textarea
              rows={4}
              placeholder="Paste raw financial text, press release, or complex journalism here..."
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-xs rounded-lg p-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono text-[11px]"
            />
            <div className="flex justify-between items-center">
              <span className="text-[11px] text-slate-400">
                Word count: {customText.trim() ? customText.trim().split(/\s+/).length : 0} words
              </span>
              <button
                onClick={handleProcessArticle}
                disabled={!customText.trim() || isProcessing}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-xs font-semibold text-white rounded-lg flex items-center gap-1.5 transition"
              >
                <Sparkles size={13} /> Run AI Simplifier
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Main Analysis Screen */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Original Source Article */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs">
              <div className="flex items-center gap-2">
                <FileText size={14} className="text-slate-400" />
                <span className="font-semibold text-slate-300">Original Financial Article</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[11px] font-mono">
                {currentArticle.source}
              </span>
            </div>

            <div className="mt-4">
              <span className="text-[11px] font-semibold text-blue-400 uppercase tracking-wider">
                {currentArticle.category}
              </span>
              <h3 className="text-base font-bold text-white mt-1 leading-snug">
                {currentArticle.title}
              </h3>
              <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-2">
                <span>{currentArticle.publishedAt}</span>
                <span>•</span>
                <span className="font-mono bg-slate-800 px-1.5 py-0.2 rounded text-slate-300">
                  {currentArticle.ticker || 'MARKET'}
                </span>
              </div>
            </div>

            <div className="mt-4 bg-slate-950 p-4 rounded-lg border border-slate-800/80 font-serif text-xs text-slate-300 leading-relaxed max-h-[380px] overflow-y-auto whitespace-pre-line">
              {currentArticle.rawText}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
            <span className="text-[11px] text-slate-400 italic">
              Contains dense Wall St terms & quantitative metrics
            </span>
            <button
              onClick={handleProcessArticle}
              disabled={isProcessing}
              className="px-3.5 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-xs font-semibold text-white rounded-lg flex items-center gap-1.5 shadow-md transition"
            >
              {isProcessing ? (
                <>
                  <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Simplifying...</span>
                </>
              ) : (
                <>
                  <Sparkles size={13} />
                  <span>Re-run AI Analysis</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: AI Simplification Output */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col relative overflow-hidden">
          {/* Animated Processing Overlay */}
          {isProcessing && (
            <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xs z-20 flex flex-col items-center justify-center p-6 text-center">
              <div className="w-12 h-12 border-3 border-blue-500 border-t-transparent rounded-full animate-spin mb-4" />
              <div className="text-sm font-bold text-white mb-1">AI Simplifier Active</div>
              <div className="text-xs text-blue-400 font-mono animate-pulse">{processingStep}</div>
              <div className="text-[11px] text-slate-400 mt-4 max-w-sm">
                Enforcing strict JSON schema, 8th-grade readability, and numerical cross-checking against source text.
              </div>
            </div>
          )}

          {/* Action Bar */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="flex h-2 w-2 rounded-full bg-emerald-400" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Simplified Plain English Breakdown
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={copySummary}
                className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition text-xs flex items-center gap-1"
                title="Copy simplified summary"
              >
                {copiedToast ? <Check size={14} className="text-emerald-400" /> : <Share2 size={14} />}
                <span className="text-[11px]">{copiedToast ? 'Copied' : 'Share'}</span>
              </button>
              <button
                onClick={() => toggleBookmark(currentArticle.id)}
                className={`p-1.5 rounded-md text-xs flex items-center gap-1 transition ${
                  isBookmarked
                    ? 'text-amber-400 bg-amber-500/10 border border-amber-500/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
                title={isBookmarked ? 'Bookmarked' : 'Add to bookmarks'}
              >
                <Bookmark size={14} fill={isBookmarked ? 'currentColor' : 'none'} />
                <span className="text-[11px]">{isBookmarked ? 'Saved' : 'Save'}</span>
              </button>
            </div>
          </div>

          {/* Sentiment & Quick Stats Header */}
          <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <div className="text-[10px] text-slate-400 uppercase tracking-wider">Market Sentiment</div>
                <div className={`text-xs font-bold flex items-center gap-1 mt-0.5 ${
                  currentArticle.simplified.sentiment.label.includes('Bullish') ? 'text-emerald-400' :
                  currentArticle.simplified.sentiment.label.includes('Bearish') ? 'text-rose-400' : 'text-amber-400'
                }`}>
                  {currentArticle.simplified.sentiment.label.includes('Bullish') ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
                  {currentArticle.simplified.sentiment.label}
                </div>
              </div>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                {Math.round(currentArticle.simplified.sentiment.score * 100)}%
              </span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">Reading Level</div>
              <div className="text-xs font-bold text-blue-400 mt-0.5">Grade 8 (Plain English)</div>
              <div className="text-[10px] text-slate-400">Zero finance background required</div>
            </div>

            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">Guardrail Status</div>
              <div className="text-xs font-bold text-emerald-400 flex items-center gap-1 mt-0.5">
                <ShieldCheck size={13} /> 100% Numbers Verified
              </div>
              <div className="text-[10px] text-slate-400">Strictly anti-hallucination audited</div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="mt-4 flex border-b border-slate-800 text-xs overflow-x-auto">
            <button
              onClick={() => setActiveTab('summary')}
              className={`pb-2 px-3 font-medium transition border-b-2 whitespace-nowrap ${
                activeTab === 'summary'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Summary & Takeaways
            </button>
            <button
              onClick={() => setActiveTab('whyItMatters')}
              className={`pb-2 px-3 font-medium transition border-b-2 whitespace-nowrap ${
                activeTab === 'whyItMatters'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Why It Matters
            </button>
            <button
              onClick={() => setActiveTab('jargon')}
              className={`pb-2 px-3 font-medium transition border-b-2 whitespace-nowrap ${
                activeTab === 'jargon'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Jargon Buster ({currentArticle.simplified.jargonBuster.length})
            </button>
            <button
              onClick={() => setActiveTab('factsVsSpeculation')}
              className={`pb-2 px-3 font-medium transition border-b-2 whitespace-nowrap ${
                activeTab === 'factsVsSpeculation'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Facts vs. Speculation
            </button>
            <button
              onClick={() => setActiveTab('entities')}
              className={`pb-2 px-3 font-medium transition border-b-2 whitespace-nowrap ${
                activeTab === 'entities'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Entities & Tickers
            </button>
          </div>

          {/* Tab Content Panes */}
          <div className="mt-4 flex-1 overflow-y-auto max-h-[420px] pr-1 space-y-4">
            {/* Tab 1: Summary */}
            {activeTab === 'summary' && (
              <div className="space-y-4">
                {/* TL;DR Box */}
                <div className="bg-gradient-to-r from-blue-950/60 to-indigo-950/40 border border-blue-800/50 p-4 rounded-xl">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-blue-300 uppercase tracking-wider mb-1.5">
                    <Sparkles size={14} className="text-blue-400" /> 30-Second TL;DR
                  </div>
                  <p className="text-sm text-slate-100 font-medium leading-relaxed">
                    {currentArticle.simplified.tldr}
                  </p>
                </div>

                {/* 3 Key Takeaways */}
                <div>
                  <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <BookOpen size={14} className="text-emerald-400" /> 3 Essential Takeaways (Numbers Preserved)
                  </div>
                  <div className="space-y-2">
                    {currentArticle.simplified.keyPoints.map((point, idx) => (
                      <div
                        key={idx}
                        className="bg-slate-950 border border-slate-800/90 rounded-lg p-3 flex items-start gap-3 text-xs text-slate-200"
                      >
                        <span className="flex items-center justify-center w-5 h-5 rounded-full bg-blue-500/20 text-blue-400 font-bold font-mono text-[11px] shrink-0">
                          {idx + 1}
                        </span>
                        <span className="leading-relaxed">{point}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Sentiment Rationale */}
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs">
                  <span className="text-slate-400 font-medium">Sentiment Rationale: </span>
                  <span className="text-slate-300">{currentArticle.simplified.sentiment.rationale}</span>
                </div>
              </div>
            )}

            {/* Tab 2: Why It Matters */}
            {activeTab === 'whyItMatters' && (
              <div className="space-y-3">
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-400 mb-1.5">
                    <span className="text-base">🛒</span> Everyday Consumer & Living Costs
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {currentArticle.simplified.whyItMatters.consumers}
                  </p>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 text-xs font-bold text-blue-400 mb-1.5">
                    <span className="text-base">📈</span> Retail Investor & 401(k) Retirement
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {currentArticle.simplified.whyItMatters.retailInvestors}
                  </p>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 mb-1.5">
                    <span className="text-base">🌐</span> Broader Macro Economy
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {currentArticle.simplified.whyItMatters.broaderEconomy}
                  </p>
                </div>
              </div>
            )}

            {/* Tab 3: Jargon Buster */}
            {activeTab === 'jargon' && (
              <div className="space-y-3">
                <div className="text-xs text-slate-400 mb-2">
                  Complex financial jargon extracted from the article with simple high-school analogies:
                </div>
                {currentArticle.simplified.jargonBuster.map((item, idx) => (
                  <div key={idx} className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-amber-400 font-mono">
                        {item.term}
                      </span>
                      <span className="text-[10px] text-slate-400 px-2 py-0.5 bg-slate-900 rounded">
                        Jargon Explained
                      </span>
                    </div>
                    <p className="text-xs text-slate-200 leading-relaxed">
                      {item.simpleExplanation}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {/* Tab 4: Facts vs. Speculation */}
            {activeTab === 'factsVsSpeculation' && (
              <div className="space-y-4">
                <div className="bg-slate-950 border border-emerald-900/30 rounded-xl p-4">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 mb-2">
                    <ShieldCheck size={14} /> Verified Hard Facts (Audited Data & Official Actions)
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {currentArticle.simplified.factsVsInterpretation.facts.map((fact, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-emerald-400">✓</span> {fact}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-slate-950 border border-amber-900/30 rounded-xl p-4">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 mb-2">
                    <Info size={14} /> Market Speculation & Analyst Interpretations
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {currentArticle.simplified.factsVsInterpretation.interpretations.map((interp, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-amber-400">?</span> {interp}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
                  <div className="text-xs font-bold text-rose-400 mb-2">
                    ⚠️ Prominent Risks & Uncertainties
                  </div>
                  <ul className="space-y-1 text-xs text-slate-300">
                    {currentArticle.simplified.risksAndUncertainties.map((risk, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-rose-400">•</span> {risk}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {/* Tab 5: Entities & Tickers */}
            {activeTab === 'entities' && (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                    <span className="text-slate-400 block mb-1 text-[11px]">Companies & Organizations:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {currentArticle.simplified.entities.companies.map((c, i) => (
                        <span key={i} className="px-2 py-0.5 bg-slate-900 border border-slate-700 rounded text-slate-200 text-[11px]">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                    <span className="text-slate-400 block mb-1 text-[11px]">Stock / Index Tickers:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {currentArticle.simplified.entities.tickers.map((t, i) => (
                        <span key={i} className="px-2 py-0.5 bg-blue-950/60 border border-blue-700/60 font-mono text-blue-300 font-bold rounded text-[11px]">
                          ${t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs">
                  <span className="text-slate-400 block mb-1 text-[11px]">Affected Sectors:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {currentArticle.simplified.entities.sectors.map((s, i) => (
                      <span key={i} className="px-2 py-0.5 bg-emerald-950/40 border border-emerald-800/40 text-emerald-300 rounded text-[11px]">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs">
                  <span className="text-slate-400 block mb-1 text-[11px]">Exact Preserved Metrics:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {currentArticle.simplified.entities.metrics.map((m, i) => (
                      <span key={i} className="px-2 py-0.5 bg-slate-900 font-mono text-amber-300 rounded text-[11px] border border-slate-700">
                        {m}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Educational Disclaimer Footer */}
          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
            <div className="flex items-center gap-1.5">
              <ShieldCheck size={13} className="text-emerald-400" />
              <span>AI-Generated Educational Analysis — Not financial or investment advice.</span>
            </div>
            <span className="font-mono text-slate-400">gemini-2.5-flash</span>
          </div>
        </div>
      </div>
    </div>
  );
};
