import React, { useState, useEffect } from 'react';
import { DEMO_VIDEO_SCRIPT_DATA } from '../data/planData';
import { Play, Pause, RotateCcw, Copy, Check, Video, Mic, CheckCircle } from 'lucide-react';

export const VideoScriptTeleprompter: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(0);
  const [seconds, setSeconds] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isRunning) {
      interval = setInterval(() => {
        setSeconds(s => s + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning]);

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const copyFullScript = () => {
    const fullText = DEMO_VIDEO_SCRIPT_DATA.map(
      s => `### ${s.step}: ${s.title}\n\n${s.speech}\n\n`
    ).join('\n');
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const currentItem = DEMO_VIDEO_SCRIPT_DATA[activeStep];

  return (
    <div className="space-y-6">
      {/* Top Banner with Teleprompter Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-white shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30">
              Mentor Review Preparation
            </span>
            <h2 className="text-xl font-bold mt-1 text-white">5–10 Minute Demo Video Rehearsal Script</h2>
            <p className="text-sm text-slate-400">
              Word-for-word spoken transcript, screen-sharing cues, and live presentation timer for your mandatory mentor video.
            </p>
          </div>

          {/* Timer & Teleprompter Controls */}
          <div className="flex items-center gap-3 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2 px-3 py-1 font-mono text-xl font-bold text-amber-400 bg-slate-900 rounded-lg border border-slate-800">
              <Mic size={18} className={isRunning ? 'text-rose-500 animate-pulse' : 'text-slate-500'} />
              <span>{formatTime(seconds)}</span>
              <span className="text-xs text-slate-500">/ 08:30</span>
            </div>

            <button
              onClick={() => setIsRunning(!isRunning)}
              className="p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition"
              title={isRunning ? 'Pause' : 'Start'}
            >
              {isRunning ? <Pause size={16} /> : <Play size={16} />}
            </button>

            <button
              onClick={() => { setIsRunning(false); setSeconds(0); }}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition"
              title="Reset Timer"
            >
              <RotateCcw size={16} />
            </button>

            <button
              onClick={copyFullScript}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 rounded-lg border border-slate-700 transition"
            >
              {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              <span>{copied ? 'Copied' : 'Copy All'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Script Explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Step Selector List */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2 max-h-[600px] overflow-y-auto">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Video size={14} className="text-blue-400" /> Presentation Agenda (10 Steps)
          </div>
          {DEMO_VIDEO_SCRIPT_DATA.map((item, idx) => (
            <button
              key={idx}
              onClick={() => setActiveStep(idx)}
              className={`w-full text-left p-3 rounded-lg border transition ${
                activeStep === idx
                  ? 'bg-blue-600/20 border-blue-500 text-white shadow-sm'
                  : 'bg-slate-950 border-slate-800/80 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-mono text-blue-400 font-semibold">{item.step.split(' ')[0]}</span>
                <span className="text-[10px] text-slate-500">{item.step.match(/\((.*?)\)/)?.[1]}</span>
              </div>
              <div className="text-xs font-medium text-slate-200 mt-1">
                {item.title}
              </div>
            </button>
          ))}
        </div>

        {/* Teleprompter Card */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-xl p-6 text-white space-y-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <span className="text-xs font-mono text-blue-400">{currentItem.step}</span>
                <h3 className="text-xl font-bold text-white mt-0.5">{currentItem.title}</h3>
              </div>
              <span className="text-xs px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono">
                Step {activeStep + 1} of 10
              </span>
            </div>

            <div className="mt-5 space-y-3">
              <div className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                <Mic size={14} /> Exactly What to Say (Word-for-Word Script):
              </div>
              <div className="bg-slate-950 p-5 rounded-xl border border-slate-800/90 font-serif text-sm text-slate-100 leading-relaxed whitespace-pre-line shadow-inner">
                {currentItem.speech}
              </div>
            </div>
          </div>

          {/* Teleprompter Navigation */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
            <button
              onClick={() => setActiveStep(prev => Math.max(0, prev - 1))}
              disabled={activeStep === 0}
              className="px-4 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 disabled:opacity-30 rounded-lg text-slate-300 transition"
            >
              ← Previous Step
            </button>

            <span className="text-xs text-slate-500">
              Aim for a calm, professional, and confident delivery.
            </span>

            <button
              onClick={() => setActiveStep(prev => Math.min(DEMO_VIDEO_SCRIPT_DATA.length - 1, prev + 1))}
              disabled={activeStep === DEMO_VIDEO_SCRIPT_DATA.length - 1}
              className="px-4 py-1.5 text-xs bg-blue-600 hover:bg-blue-500 disabled:opacity-30 rounded-lg font-medium text-white transition"
            >
              Next Step →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
