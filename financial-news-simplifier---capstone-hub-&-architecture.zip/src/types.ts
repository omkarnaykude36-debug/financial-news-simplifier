export type KanbanStatus = 'To Do' | 'In Progress' | 'Review';

export interface KanbanTask {
  id: string;
  task: string;
  epic: string;
  phase: string;
  status: KanbanStatus;
  dependency: string;
  deliverable: string;
  description?: string;
  acceptanceCriteria?: string[];
  definitionOfDone?: string[];
}

export interface UserStory {
  id: string;
  epic: string;
  story: string;
  acceptanceCriteria: string[];
  priority: 'High' | 'Medium' | 'Low';
  dependencies: string;
  definitionOfDone: string[];
  suggestedKanbanStatus: KanbanStatus;
}

export interface ArticleSample {
  id: string;
  title: string;
  source: string;
  publishedAt: string;
  category: string;
  rawText: string;
  ticker?: string;
  simplified: {
    tldr: string;
    keyPoints: string[];
    sentiment: {
      label: 'Bullish / Positive' | 'Bearish / Negative' | 'Neutral / Mixed';
      score: number;
      rationale: string;
    };
    whyItMatters: {
      retailInvestors: string;
      consumers: string;
      broaderEconomy: string;
    };
    jargonBuster: Array<{ term: string; simpleExplanation: string }>;
    entities: {
      companies: string[];
      sectors: string[];
      tickers: string[];
      metrics: string[];
    };
    factsVsInterpretation: {
      facts: string[];
      interpretations: string[];
    };
    risksAndUncertainties: string[];
  };
}

export interface DatabaseField {
  name: string;
  type: string;
  description: string;
  isPk?: boolean;
  isFk?: boolean;
  refTable?: string;
  nullable?: boolean;
}

export interface DatabaseTable {
  name: string;
  description: string;
  fields: DatabaseField[];
}

export interface ApiEndpoint {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  endpoint: string;
  purpose: string;
  authRequired: boolean;
  requestParamsOrBody: string;
  responseStructure: string;
}

export interface PromptTemplate {
  id: string;
  title: string;
  purpose: string;
  systemPrompt: string;
  userPromptTemplate: string;
  jsonOutputSchema: string;
  safeguards: string[];
}
